﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetupDestroy : MonoBehaviour {

    public GameObject setupOverlord;
    public PlayerStats setupTrigger;
    private void Start()
    {
        setupOverlord = GameObject.Find("Monster1");
        setupTrigger = setupOverlord.GetComponent<PlayerStats>();
    }
    void Update()
    {
        
            if(setupTrigger.overlordSetup == false)
            {
                Destroy(gameObject);
            }
        
    }
}
