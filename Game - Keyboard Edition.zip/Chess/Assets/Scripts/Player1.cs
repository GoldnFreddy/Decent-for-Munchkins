﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player1 : PlayerScript {
    private void Start()
    {
        gController = GameObject.Find("GameController");
        gControllerScript = gController.GetComponent<GameController>();
    }
    //for the game controller variable accessing
    protected override void Update()
    {
        if (gControllerScript.turn == 0)
        {

            //Calling the diceroll void
            Diceroll();
            //Highlighting enemies
            if (rangeRoll == true)
            {
                if (isInRange == true)
                {
                    EnemyInRange();
                    isInRange = false;
                }
            }
            else
            {
                if (isInRange == false)
                {
                    EnemyNotInRange();
                    isInRange = true;
                }
            }
            Rays();
        }
        
    }

    protected override void Diceroll()
    {

        //rolling dice to get results
        if (rangeRoll == false)
        {
            if (Input.GetKeyDown(KeyCode.Keypad5))
            {
                range = Random.Range(0, 10);
                rangeRoll = true;
                Debug.Log("P1 rolled " + range + " for range.");
            }
        }
        else
        {
            if (attackRoll == false)
            {
                if (Input.GetKeyDown(KeyCode.Keypad5))
                {
                    damage = Random.Range(1, 6);
                    attackRoll = true;
                    Debug.Log("P1 rolled " + damage + " for attack.");
                }
            }
            else
            {
                if (Input.GetKeyDown(KeyCode.Keypad5))
                {
                    
                    attackRoll = false;
                    rangeRoll = false;
                    range = 0;
                    damage = 0;
                    Debug.Log("P1 ended their turn");
                    gControllerScript.turn = 1;
                }
            }
        }
    }
    protected override void Rays()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));
        //Debugging that tells in console if the raycasts actually hit their intended targets
        if (attackRoll == true)
        {
            if (isDone == false)
            {

                if (Input.GetKeyDown(KeyCode.Keypad8))
                {
                    if (Physics.Raycast(transform.position, fwd, out hit, range))
                    {
                        if (hit.transform.tag == "Monster")
                        {

                            //activates void in other object with the name "hit by ray"
                            hit.transform.SendMessage("HitByRay");
                            isDone = true;
                            range = 0;
                        }
                    }
                }
                if (Input.GetKeyDown(KeyCode.Keypad2))
                {
                    if (Physics.Raycast(transform.position, bck, out hit, range))
                    {
                        if (hit.transform.tag == "Monster")
                        {
                            hit.transform.SendMessage("HitByRay");
                            isDone = true;
                            range = 0;
                        }
                    }
                }
                if (Input.GetKeyDown(KeyCode.Keypad4))
                {
                    if (Physics.Raycast(transform.position, lft, out hit, range))
                    {
                        if (hit.transform.tag == "Monster")
                        {
                            hit.transform.SendMessage("HitByRay");
                            isDone = true;
                            range = 0;
                        }
                    }
                }
                if (Input.GetKeyDown(KeyCode.Keypad6))
                {
                    if (Physics.Raycast(transform.position, rgt, out hit, range))
                    {
                        if (hit.transform.tag == "Monster")
                        {
                            hit.transform.SendMessage("HitByRay");
                            isDone = true;
                            range = 0;
                        }
                    }
                }
                if (Input.GetKeyDown(KeyCode.Keypad7))
                {
                    if (Physics.Raycast(transform.position, fwd_lft, out hit, range))
                    {
                        if (hit.transform.tag == "Monster")
                        {
                            hit.transform.SendMessage("HitByRay");
                            isDone = true;
                            range = 0;
                        }
                    }
                }
                if (Input.GetKeyDown(KeyCode.Keypad9))
                {
                    if (Physics.Raycast(transform.position, fwd_rgt, out hit, range))
                    {
                        if (hit.transform.tag == "Monster")
                        {
                            hit.transform.SendMessage("HitByRay");
                            isDone = true;
                            range = 0;
                        }
                    }
                }
                if (Input.GetKeyDown(KeyCode.Keypad1))
                {
                    if (Physics.Raycast(transform.position, bck_lft, out hit, range))
                    {
                        if (hit.transform.tag == "Monster")
                        {
                            hit.transform.SendMessage("HitByRay");
                            isDone = true;
                            range = 0;
                        }
                    }
                }
                if (Input.GetKeyDown(KeyCode.Keypad3))
                {
                    if (Physics.Raycast(transform.position, bck_rgt, out hit, range))
                    {
                        if (hit.transform.tag == "Monster")
                        {
                            hit.transform.SendMessage("HitByRay");
                            isDone = true;
                            range = 0;
                        }
                    }
                }
            }
        }
    }
}
