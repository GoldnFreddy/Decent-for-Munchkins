﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
public class PlayerScript : MonoBehaviour {
    public List<GameObject> players;
    public GameObject currentPlayer;
    public int pointer;

    public AttackScript fight;
    public MoveScript move;
    // Use this for initialization
    void Start () {
        
        players.Add(GameObject.Find("Player1"));
        players.Add(GameObject.Find("Monster1"));

    }
    void Turn()
    {
        
        if (pointer < (players.Count-1))
          {
            pointer++;
          }
        else
        {
            pointer = 0;
        }   
            currentPlayer = players[pointer];    
    }
	// Update is called once per frame
	void Update () {

        move = currentPlayer.GetComponent<MoveScript>();
        move.Movement();
        fight = currentPlayer.GetComponent<AttackScript>();
        fight.Diceroll();
        fight.Battle();
        if (Input.GetKeyDown(KeyCode.Keypad5))
        {
            move.canMove = false;
            move.moveCounter = 0;
            
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            fight.RefreshAttack();
            fight.NotInRange();
            
            Turn();
            
            Debug.Log("It is now the turn of " + currentPlayer);
            move.RefreshMovement();
            
        }
        
    }
}
