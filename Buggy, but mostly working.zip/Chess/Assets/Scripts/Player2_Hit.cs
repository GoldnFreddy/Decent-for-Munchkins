﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player2_Hit : PlayerHit {
    public GameController gControllerScript;
    public GameObject gController;

    bool counterLowered = false;
    protected override void Start()
    {
        tstPlayer = GameObject.FindGameObjectWithTag("Player");
        rayScript = tstPlayer.GetComponent<PlayerScript>();

        gController = GameObject.Find("GameController");
        gControllerScript = gController.GetComponent<GameController>();

        //Fetch the Material from the Renderer of the GameObject
        m_Material = GetComponent<Renderer>().material;
    }
    private void Update()
    {
        if (health <= 0)
        {
            if(counterLowered == false)
            {
                gControllerScript.overlordCounter -= 1;
                counterLowered = true;
                transform.Translate(0, -10, 0);
            }
            if (gControllerScript.turn == 1)
            {
                gControllerScript.turn = 2;
            }
        }
    }
    protected override void DefenceDiceRoll()
    {
        dice = Random.Range(0, 6);
        switch (dice)
        {
            case 0:
                defence = 0;
                break;
            case 1:
                defence = 1;
                break;
            case 2:
                defence = 1;
                break;
            case 3:
                defence = 1;
                break;
            case 4:
                defence = 2;
                break;
            case 5:
                defence = 3;
                break;
        }
        Debug.Log("I rolled " + defence + " points of defence");
    }
}
