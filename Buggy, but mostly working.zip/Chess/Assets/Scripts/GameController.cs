﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {
    //Runs turns and activates movement
    public Player1_Move pMovementScript1;
    public GameObject Player1;

    public Player2_Move pMovementScript2;
    public GameObject Player2;

    public Monster2_Move pMovementScript3;
    public GameObject Monster2;

    public Monster3_Move pMovementScript4;
    public GameObject Monster3;

    public int overlordCounter = 3;

    public int turn = 1;
    bool isDone = false;
    private void Start()
    {
        Player1 = GameObject.Find("Player");
        pMovementScript1 = Player1.GetComponent<Player1_Move>();
        Player2 = GameObject.Find("Monster");
        pMovementScript2 = Player2.GetComponent<Player2_Move>();
    }
    private void Update()
    {
        if(turn == 0)
        {
            if(isDone == false)
            {
                pMovementScript1.canMove = true;
                isDone = true;
            }
        }
        else if(turn == 1)
        {
            if(isDone == true)
            {
                pMovementScript2.canMove = true;
                isDone = false;
            }
        }
        else if (turn == 2)
        {
            if (isDone == false)
            {
                pMovementScript3.canMove = true;
                isDone = true;
            }
        }
        else if (turn == 3)
        {
            if (isDone == true)
            {
                pMovementScript4.canMove = true;
                isDone = false;
            }
        }
    }
}
