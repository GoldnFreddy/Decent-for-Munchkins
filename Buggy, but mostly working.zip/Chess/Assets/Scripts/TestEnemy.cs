﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestEnemy : MonoBehaviour {
    //enemy script Antoni Gudejko
    public PlayerScript rayScript;
    public GameObject tstPlayer;
    Material m_Material;
    int defence = 0;
    int health = 3;
    int damageDealt = 0;
    // Use this for initialization
    void Start () {
        tstPlayer = GameObject.Find("Player");
        rayScript = tstPlayer.GetComponent<PlayerScript>();
        
        //Fetch the Material from the Renderer of the GameObject
        m_Material = GetComponent<Renderer>().material;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    
    void HitByRay()
    {
        DefenceDiceRoll();
        damageDealt = rayScript.damage - defence;
        if (damageDealt < 0)
        {
            damageDealt = 0;
        }
        Debug.Log("I was hit by a total of " + damageDealt + " damage");
        
        //Self-explanatory name to be honest
        health = health - damageDealt;
        Debug.Log("My total health after being hit is " + health + "." );
    }
    void InRange()
    {

        
            // Change the Color of the GameObject when it is in range
            m_Material.color = Color.red; 
    }
    void NotInRange()
    {
        m_Material.color = Color.white;
    }
    void DefenceDiceRoll()
    {
        defence = Random.Range(0, 3);
        Debug.Log("I rolled " + defence + " points of defence");
    }
}
