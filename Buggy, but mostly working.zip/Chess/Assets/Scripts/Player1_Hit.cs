﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player1_Hit : PlayerHit {
    public GameController gControllerScript;
    public GameObject gController;
    protected override void Start()
    {
        tstPlayer = GameObject.FindGameObjectWithTag("Monster");
        rayScript = tstPlayer.GetComponent<PlayerScript>();

        gController = GameObject.Find("GameController");
        gControllerScript = gController.GetComponent<GameController>();

        //Fetch the Material from the Renderer of the GameObject
        m_Material = GetComponent<Renderer>().material;
    }
    private void Update()
    {
        if(health <= 0)
        {
            Debug.Log("Player1 Died, Overlord Wins!");
            gControllerScript.turn = 10;
        }
    }
    protected override void DefenceDiceRoll()
    {
        dice = Random.Range(0, 6);
        switch (dice)
        {
            case 0:
                defence = 0;
                break;
            case 1:
                defence = 1;
                break;
            case 2:
                defence = 1;
                break;
            case 3:
                defence = 1;
                break;
            case 4:
                defence = 2;
                break;
            case 5:
                defence = 3;
                break;
        }
        Debug.Log("I rolled " + defence + " points of defence");
    }
}
