﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster3_Move : MonoBehaviour {
    RaycastHit hit;
    int moveCounter = 0;
    
    public bool canMove = true;
    public GameController gControllerScript;
    public GameObject gController;
    // Use this for initialization
    void Start()
    {
        gController = GameObject.Find("GameController");
        gControllerScript = gController.GetComponent<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (gControllerScript.turn == 3)
        {
            if (Input.GetKeyDown(KeyCode.Keypad5))
            {
                canMove = false;
                moveCounter = 0;
            }

            if (canMove == true)
            {


                if (moveCounter >= 3)
                {
                    print("Out of moves");
                    canMove = false;
                    moveCounter = 0;
                }

                Vector3 dwn = transform.TransformDirection(Vector3.down);
                //Player Movement
                if (Input.GetKeyDown(KeyCode.Keypad8))
                {
                    //transform.parent = null;
                    transform.Translate(0, 0, 1);
                    moveCounter += 1;
                    //check for ground
                    if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                    {
                    }
                    else
                    {
                        moveCounter -= 1;
                        transform.Translate(0, 0, -1);
                    }
                }
                else if (Input.GetKeyDown(KeyCode.Keypad2))
                {
                    //transform.parent = null;
                    transform.Translate(0, 0, -1);
                    moveCounter += 1;
                    if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                    {
                    }
                    else
                    {
                        moveCounter -= 1;
                        transform.Translate(0, 0, 1);
                    }
                }
                else if (Input.GetKeyDown(KeyCode.Keypad4))
                {
                    transform.Translate(-1, 0, 0);
                    moveCounter += 1;
                    if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                    {
                    }
                    else
                    {
                        moveCounter -= 1;
                        transform.Translate(1, 0, 0);
                    }
                }
                else if (Input.GetKeyDown(KeyCode.Keypad6))
                {
                    transform.Translate(1, 0, 0);
                    moveCounter += 1;
                    if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                    {
                    }
                    else
                    {
                        moveCounter -= 1;
                        transform.Translate(-1, 0, 0);
                    }
                }
                else if (Input.GetKeyDown(KeyCode.Keypad7))
                {
                    transform.Translate(-1, 0, 1);
                    moveCounter += 1;
                    if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                    {
                    }
                    else
                    {
                        moveCounter -= 1;
                        transform.Translate(1, 0, -1);
                    }
                }
                else if (Input.GetKeyDown(KeyCode.Keypad9))
                {
                    transform.Translate(1, 0, 1);
                    moveCounter += 1;
                    if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                    {
                    }
                    else
                    {
                        moveCounter -= 1;
                        transform.Translate(-1, 0, -1);
                    }
                }
                else if (Input.GetKeyDown(KeyCode.Keypad1))
                {
                    transform.Translate(-1, 0, -1);
                    moveCounter += 1;
                    if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                    {
                    }
                    else
                    {
                        moveCounter -= 1;
                        transform.Translate(1, 0, 1);
                    }
                }
                else if (Input.GetKeyDown(KeyCode.Keypad3))
                {
                    transform.Translate(1, 0, -1);
                    moveCounter += 1;
                    if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                    {
                    }
                    else
                    {
                        moveCounter -= 1;
                        transform.Translate(-1, 0, 1);
                    }
                }
            }

        }
    }
}
