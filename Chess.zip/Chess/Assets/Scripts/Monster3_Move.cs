﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster3_Move : MonoBehaviour {

    int direction_y = 0;
    int direction_x = 0;
    public bool canMove = true;
    public GameController gControllerScript;
    public GameObject gController;
    // Use this for initialization
    void Start()
    {
        gController = GameObject.Find("GameController");
        gControllerScript = gController.GetComponent<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (gControllerScript.turn == 3)
        {

            if (canMove == true)
            {


                if (direction_x + direction_y >= 3)
                {
                    print("Out of moves");
                    canMove = false;
                    direction_y = 0;
                    direction_x = 0;
                }
                if (direction_x + direction_y <= -3)
                {
                    print("Out of moves");
                    canMove = false;
                    direction_y = 0;
                    direction_x = 0;
                }

                //Player Movement
                if (Input.GetKeyDown(KeyCode.UpArrow))
                {
                    //transform.parent = null;
                    transform.Translate(0, 0, 1);
                    direction_y += 1;
                }
                if (Input.GetKeyDown(KeyCode.DownArrow))
                {
                    //transform.parent = null;
                    transform.Translate(0, 0, -1);
                    direction_y -= 1;
                }
                if (Input.GetKeyDown(KeyCode.LeftArrow))
                {
                    transform.Translate(-1, 0, 0);
                    direction_x += 1;
                }
                if (Input.GetKeyDown(KeyCode.RightArrow))
                {
                    transform.Translate(1, 0, 0);
                    direction_x -= 1;
                }
            }

        }
    }
}
