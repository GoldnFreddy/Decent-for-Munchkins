﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster3 : PlayerScript {

    private void Start()
    {
        gController = GameObject.Find("GameController");
        gControllerScript = gController.GetComponent<GameController>();
    }
    protected override void Update()
    {
        if (gControllerScript.turn == 3)
        {

            //Calling the diceroll void
            Diceroll();
            //Highlighting enemies
            if (rangeRoll == true)
            {
                if (isInRange == true)
                {
                    EnemyInRange();
                    isInRange = false;
                }
            }
            else
            {
                if (isInRange == false)
                {
                    EnemyNotInRange();
                    isInRange = true;
                }
            }
            Rays();
        }

    }
    protected override void Diceroll()
    {

        //rolling dice to get results
        if (rangeRoll == false)
        {
            if (Input.GetKeyDown(KeyCode.Keypad5))
            {
                range = Random.Range(0, 10);
                rangeRoll = true;
                Debug.Log("Monster3 rolled " + range + " for range.");
            }
        }
        else
        {
            if (attackRoll == false)
            {
                if (Input.GetKeyDown(KeyCode.Keypad5))
                {
                    damage = Random.Range(1, 6);
                    attackRoll = true;
                    Debug.Log("Monster3 rolled " + damage + " for attack.");
                }
            }
            else
            {
                if (Input.GetKeyDown(KeyCode.Keypad5))
                {
                    attackRoll = false;
                    rangeRoll = false;
                    range = 0;
                    damage = 0;
                    Debug.Log("Monster3 ended their turn");
                    gControllerScript.turn = 0;
                }
            }
        }
    }
}
