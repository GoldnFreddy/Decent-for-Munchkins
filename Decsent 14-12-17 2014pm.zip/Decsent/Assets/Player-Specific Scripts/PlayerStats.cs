﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour {

    public int speed = 0;//characterspeed
    public int health = 3;//characterhealth
    public string attackDiceType = "BlueYellow";
    public string defenceDiceType = "Grey";
    //public enum Alignement (Hero,Villain); - It says that it requires c# 7 and that I only have c#4
    public bool isHero = false;//
    public bool overlordSetup = true;//
    public string playerName;
}
