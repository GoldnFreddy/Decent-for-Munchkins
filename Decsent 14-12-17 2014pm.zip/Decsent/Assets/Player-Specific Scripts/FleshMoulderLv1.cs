﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FleshMoulderLv1 : PlayerStats {
}
