﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class exit_game : MonoBehaviour {

	
	
	// Update is called once per frame
public void exitgame () {
        Application.Quit();
	}
}
