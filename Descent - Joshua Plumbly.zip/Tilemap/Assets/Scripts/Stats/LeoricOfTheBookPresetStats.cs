﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeoricOfTheBookPresetStats : BaseCharacterClass
{
    public LeoricOfTheBookPresetStats()
    {
        CharacterName = "Leoric of the Book";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Mage;
        CharacterClass = enumCharacterClass.Error;
        Speed = 4;
        Health = 8;
        Stamina = 5;
        Defence = enumDefence.oneGrayDice;
        Might = 1;
        Knowledge = 5;
        Willpower = 2;
        Awareness = 3;
    }
}
