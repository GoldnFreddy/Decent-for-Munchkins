﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridHighlight : MonoBehaviour {

    public static GridHighlight Instance { set; get; }

    public GameObject highlightPrefab;
    private List<GameObject> highlightsList;

    private void Start()
    {
        Instance = this;
        highlightsList = new List<GameObject>();
    }

    private GameObject GetHighlightObject()
    {
        GameObject go = highlightsList.Find(global => !global.activeSelf);

        if (go == null)
        {
            go = Instantiate(highlightPrefab);
            highlightsList.Add(go);
        }

        return go;
    }

    public void HighightAllowedMoves(bool[,] moves)
    {
        for(int i = 0; i < 13; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (moves [i,j])
                {
                    GameObject go = GetHighlightObject();
                    go.SetActive(true);
                    go.transform.position = new Vector3(i+0.5f, 0, j+0.5f);
                }
            }
        }
    }

    public void Highlights()
    {
        foreach (GameObject go in highlightsList)
            go.SetActive(false);
    }
}