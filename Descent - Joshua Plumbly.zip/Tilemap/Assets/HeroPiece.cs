﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroPiece : Piece {

    public override bool[,] PossibleMove()
    {
        bool[,] r = new bool[13, 13];
        r[3, 3] = true;
        return base.PossibleMove();
    }
}
