﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour {

    public static GridManager Instance { set; get; }
    private bool[,] allowedMoves { set; get; }

    //public character
    [SerializeField] public Piece[,] Pieces { set; get; }
    [SerializeField] private Piece selectedPiece;
    [SerializeField] private Piece currentPiece;

    [SerializeField] private const float tileSize = 1.0f;
    [SerializeField] private const float tileOffset = 0.5f;

    [SerializeField] private int selectionX = -1;
    [SerializeField] private int selectionY = -1;

    [SerializeField] private int gridHeight;
    [SerializeField] private int gridWidth;

    [SerializeField] private List<GameObject> piecesPrefabList;
    [SerializeField] private List<GameObject> activePieceList;

    private void Start()
    {
        SpawnPices();
    }

    private void Update()
    {
        UpdateSelection();
        DrawGrid();

        if (Input.GetMouseButtonDown (0))
        {
            if(selectionX >= 0 && selectionY >=0)
            {
                //SelectPiece(selectionX, selectionY);
            }
        }
    }

    private void UpdateSelection()
    {
        if (!Camera.main)
            return;

        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 50.0f, LayerMask.GetMask("GridPlane")))
        {
            Debug.Log(hit.point);
            selectionX = (int)hit.point.x;
            selectionY = (int)hit.point.z;
        }
        else
        {
            selectionX = -1;
            selectionY = -1;
        }
    }

    private void SpawnPices()
    {
        SpawnPiece(0, 3, 3);
        SpawnPiece(0, 0, 0);
    }

    private void SpawnPiece(int index, int x, int y)
    {
        GameObject go = Instantiate(piecesPrefabList[index], GetTileCenter(x,y), Quaternion.identity) as GameObject;
        Pieces[x,y] = go.GetComponent<Piece>();
        Pieces[x, y].SetPostion(x, y);
        activePieceList.Add(go);
    }

    private Vector3 GetTileCenter(int x , int y)
    {
        Vector3 origin = Vector3.zero;
        origin.x += (tileSize * x) + tileOffset;
        origin.z += (tileSize * y) + tileOffset;
        return origin;
    }


    public void SelectPiece(int x, int y)
    {
        if (Pieces[x, y] == null)
            return;

        /*if (Pieces[x,y])
        {
            
        }*/

        selectedPiece = Pieces[x, y];

        allowedMoves = Pieces[x, y].PossibleMove(x,y);
        selectedPiece = Pieces[x, y];
        GridHighlight.Instance.HighightAllowedMoves(allowedMoves);
    }

    public void MovePiece(int x, int y)
    {
        if (allowedMoves[x, y] == true)
        {
            /*Pieces[currentPiece.CurrentX, currentPiece.CurrentY] = null;
            currentPiece.transform.position = GetTileCenter(x, y);
            Pieces 
            Pieces [x, y] = currentPiece;

            BoardHighlights.Instabce.Hi
            selectedPiece = null;*/
        }
    }

    private void DrawGrid()
    {
        Vector3 widthLine = Vector3.right * gridWidth;
        Vector3 heightLine = Vector3.forward * gridWidth;

        for (int i = 0; i <= gridWidth; i++)
        {
            Vector3 start = Vector3.forward * i;
            Debug.DrawLine(start, start + widthLine);
            for (int j = 0; j <= gridWidth; j++)
            {
                start = Vector3.right * j;
                Debug.DrawLine(start, start + heightLine);
            }
        }

        // Draw selected tile.
        if (selectionX >= 0 && selectionY >= 0)
        {
            Debug.DrawLine(
                Vector3.forward * selectionY + Vector3.right * selectionX,
                Vector3.forward * (selectionY + 1) + Vector3.right * (selectionX + 1));

            Debug.DrawLine(
            Vector3.forward * (selectionY + 1) + Vector3.right * selectionX,
            Vector3.forward * selectionY + Vector3.right * (selectionX + 1));
        }
    }
}
