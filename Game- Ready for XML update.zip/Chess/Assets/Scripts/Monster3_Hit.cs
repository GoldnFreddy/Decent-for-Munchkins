﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster3_Hit : PlayerHit {

    protected override void Start()
    {
        tstPlayer = GameObject.FindGameObjectWithTag("Player");
        rayScript = tstPlayer.GetComponent<PlayerScript>();

        //Fetch the Material from the Renderer of the GameObject
        m_Material = GetComponent<Renderer>().material;
    }
}
