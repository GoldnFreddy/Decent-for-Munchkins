﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster3 : PlayerScript {

    private void Start()
    {
        gController = GameObject.Find("GameController");
        gControllerScript = gController.GetComponent<GameController>();
    }
    protected override void Update()
    {
        if (gControllerScript.turn == 3)
        {

            //Calling the diceroll void
            Diceroll();
            //Highlighting enemies
            if (rangeRoll == true)
            {
                if (isInRange == true)
                {
                    EnemyInRange();
                    isInRange = false;
                }
            }
            else
            {
                if (isInRange == false)
                {
                    EnemyNotInRange();
                    isInRange = true;
                }
            }
            Rays();
        }

    }
    protected override void Diceroll()
    {

        //rolling dice to get results
        if (rangeRoll == false)
        {
            if (Input.GetKeyDown(KeyCode.Keypad5))
            {
                range = Random.Range(0, 10);
                rangeRoll = true;
                Debug.Log("Monster3 rolled " + range + " for range.");
            }
        }
        else
        {
            if (attackRoll == false)
            {
                if (Input.GetKeyDown(KeyCode.Keypad5))
                {
                    damage = Random.Range(1, 6);
                    attackRoll = true;
                    Debug.Log("Monster3 rolled " + damage + " for attack.");
                }
            }
            else
            {
                if (Input.GetKeyDown(KeyCode.Keypad5))
                {
                    attackRoll = false;
                    rangeRoll = false;
                    range = 0;
                    damage = 0;
                    Debug.Log("Monster3 ended their turn");
                    gControllerScript.turn = 0;
                }
            }
        }
    }
    protected override void Rays()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));
        //Debugging that tells in console if the raycasts actually hit their intended targets
        if (attackRoll == true)
        {
            if (isDone == false)
            {
                Vector3 direction = Vector3.zero;

                if (Input.GetKeyDown(KeyCode.Keypad8))
                    direction = fwd;
                else if (Input.GetKeyDown(KeyCode.Keypad2))
                    direction = bck;
                else if (Input.GetKeyDown(KeyCode.Keypad4))
                    direction = lft;
                else if (Input.GetKeyDown(KeyCode.Keypad6))
                    direction = rgt;
                else if (Input.GetKeyDown(KeyCode.Keypad7))
                    direction = fwd_lft;
                else if (Input.GetKeyDown(KeyCode.Keypad9))
                    direction = fwd_rgt;
                else if (Input.GetKeyDown(KeyCode.Keypad1))
                    direction = bck_lft;
                else if (Input.GetKeyDown(KeyCode.Keypad3))
                    direction = bck_rgt;

                if (direction != Vector3.zero)
                {
                    if (Physics.Raycast(transform.position, direction, out hit, range) && hit.transform.tag == "Player")
                    {
                        //activates void in other object with the name "hit by ray"
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;

                    }
                }
            }
        }

    }
    protected override void EnemyInRange()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));

        if (Physics.Raycast(transform.position, fwd, out hit, range) && hit.transform.tag == "Player")
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck, out hit, range) && hit.transform.tag == "Player")
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, lft, out hit, range) && hit.transform.tag == "Player")
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, rgt, out hit, range) && hit.transform.tag == "Player")
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, fwd_lft, out hit, range) && hit.transform.tag == "Player")
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, fwd_rgt, out hit, range) && hit.transform.tag == "Player")
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck_lft, out hit, range) && hit.transform.tag == "Player")
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck_rgt, out hit, range) && hit.transform.tag == "Player")
        {
            hit.transform.SendMessage("InRange");
        }
    }
}
