﻿
public class HeroStats : BaseCharacterClass
{
    public HeroStats()
    {
        CharacterName = "Hero";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Warrior;
        CharacterClass = enumCharacterClass.Error;
        Speed = 0;
        Health = 0;
        Stamina = 0;
        Defence = enumDefence.oneGrayDice;
        Might = 0;
        Knowledge = 0;
        Willpower = 0;
        Awareness = 0;
    }
}