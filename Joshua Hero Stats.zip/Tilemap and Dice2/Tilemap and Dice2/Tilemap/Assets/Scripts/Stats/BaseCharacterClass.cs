﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseCharacterClass : MonoBehaviour {

    [SerializeField] private string characterName;
    [SerializeField] private string characterDescription;

    [SerializeField] public enum enumArchetypes
    {
        Scout,
        Warrior,
        Mage,
        Healer
    }

    [SerializeField] public enum enumCharacterClass
    {
        Error,

        // Scount
        BountyHunter,
        Monk,
        ShadowWalker,
        Stalker,
        Thief,
        TreasureHunter,
        Windlander,
        
        //Warrior
        Beastmaster,
        Berserker,
        Champition,
        Knight,
        Marshal,
        Skirmisher,
        Steelcaster,

        // Mage
        Battlemage,
        Conjurer,
        Geomancer,
        Hexer,
        Necromancer,
        Runemaster,
            
        // Healler
        Apothecary,
        Bard,
        Disciple,
        Prophet,
        Spitirspeaker,
        Watchman
    };

    [SerializeField] public enum enumDefence
    {
       oneGrayDice,
       oneBrownDice,
       oneBlackDice
    };

    [SerializeField] private enumArchetypes archetype;
    [SerializeField] private enumCharacterClass characterClass;

    [SerializeField] private int speed;
    [SerializeField] private int health;
    [SerializeField] private int stamina;
    [SerializeField] private enumDefence defence;

    [SerializeField] private int might;
    [SerializeField] private int knowledge;
    [SerializeField] private int willpower;
    [SerializeField] private int awareness;

    /// Name
    public string CharacterName
    {
        get { return characterName; }
        set { characterName = value; }
    }

    public string CharacterDescription
    {
        get { return characterDescription; }
        set { characterDescription = value; }
    }

    public enumArchetypes ArcheTypes
    {
        get { return archetype; }
        set { archetype = value; }
    }

    public enumCharacterClass CharacterClass
    {
        get { return characterClass; }
        set { characterClass = value; }
    }

    /// Characteristics
    public int Speed
    {
        get { return speed; }
        set { speed = value; }
    }

    public int Health
    {
        get { return health; }
        set { health = value; }
    }

    public int Stamina
    {
        get { return stamina; }
        set { stamina = value; }
    }

    public enumDefence Defence
    {
        get { return defence; }
        set { defence = value; }
    }

    /// Attributes 
    public int Might
    {
        get { return might; }
        set { might = value; }
    }

    public int Knowledge
    {
        get { return knowledge; }
        set { knowledge = value; }
    }

    public int Willpower
    {
        get { return willpower; }
        set { willpower = value; }
    }

    public int Awareness
    {
        get { return awareness; }
        set { awareness = value; }
    }


}
