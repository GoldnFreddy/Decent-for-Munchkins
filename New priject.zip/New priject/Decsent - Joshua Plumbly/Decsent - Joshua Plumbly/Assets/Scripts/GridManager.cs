﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{

    [SerializeField] public bool moveButtonSelected = true;

    [SerializeField] public static GridManager Instance { set; get; }
    [SerializeField] private bool[,] allowedMoves { set; get; }

    //public character
    [SerializeField] public Piece[,] Pieces { set; get; }
    [SerializeField] private Piece selectedPiece;
    [SerializeField] private Piece currentPiece;

    [SerializeField] private const float tileSize = 1.0f;
    [SerializeField] private const float tileOffset = 0.5f;

    [SerializeField] private int selectionX = -1;
    [SerializeField] private int selectionY = -1;

    [SerializeField] private int gridHeight;
    [SerializeField] private int gridWidth = 13;

    [SerializeField] Quaternion orientation = Quaternion.Euler(0, 180, 0);

    [SerializeField] private List<GameObject> piecesPrefabList;
    [SerializeField] private List<GameObject> activePieceList = new List<GameObject>();

    /// <summary>
    /// Runs when this sqript is first activated.
    /// </summary>
    private void Start()
    {
        SpawnPicesAtStart();
        //ChanageCurrentPiece();
    }

    /// <summary>
    /// Runs evary frame.
    /// </summary>
    private void Update()
    {
        UpdateSelection();
        DrawGrid();

        if (Input.GetMouseButtonDown(0))
        {
            if (moveButtonSelected == true)
            {
                Debug.Log("Move button is on and the mouse button has been click.");
                MovePiece(selectionX, selectionY);
            }


            if (selectionX >= 0 && selectionY >= 0)
            {
                if (currentPiece == null)
                {
                    ChanageCurrentPiece(selectionX, selectionY);
                }
            }
        }
    }

    /// <summary>
    /// Finds the position of the mouse and selects the tile that it is hoving over.
    /// </summary>
    private void UpdateSelection()
    {
        if (!Camera.main)
            return;

        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 50.0f, LayerMask.GetMask("GridPlane")))
        {
            //Debug.Log(hit.point);
            selectionX = (int)hit.point.x;
            selectionY = (int)hit.point.z;
        }
        else
        {
            selectionX = -1;
            selectionY = -1;
        }
    }

    /// <summary>
    /// Spawns a list of GameObjects at the start of the game.
    /// </summary>
    private void SpawnPicesAtStart()
    {
        activePieceList = new List<GameObject>();
        Pieces = new Piece[13, 13];

        SpawnPiece(0, 3, 3);
        SpawnPiece(0, 0, 0);
    }

    /// <summary>
    /// Spawns game objects to the grid.
    /// </summary>
    /// <param name="index"></param>
    /// <param name="x"></param>
    /// <param name="y"></param>
    private void SpawnPiece(int index, int x, int y)
    {
        GameObject go = Instantiate(piecesPrefabList[index], GetTileCenter(x, y), orientation) as GameObject;
        go.transform.SetParent(transform);
        Pieces[x, y] = go.GetComponent<Piece>();
        Pieces[x, y].SetPostion(x, y);
        activePieceList.Add(go);
    }

    /// <summary>
    /// Used by a UI button that is activated by the mouse.
    /// Toggles the move bool.
    /// </summary>
    public void ButtonMoveFuncion()
    {
        //Debug.Log("Move Button Selected.");
        moveButtonSelected = !moveButtonSelected;
    }

    /// <summary>
    /// Converts Unity's vector 3 positions to the grid.  
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <returns></returns>
    private Vector3 GetTileCenter(int x, int y)
    {
        Vector3 origin = Vector3.zero;
        origin.x += (tileSize * x) + tileOffset;
        origin.z += (tileSize * y) + tileOffset;
        return origin;
    }

    /// <summary>
    /// Chanage the current piece based on the player's turn.
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    public void ChanageCurrentPiece(int x, int y)
    {
        allowedMoves = Pieces[x, y].PossibleMove();
        currentPiece = Pieces[x, y];
        GridHighlight.Instance.HighightAllowedMoves(allowedMoves);
    }

    /// <summary>
    /// To be used for selecting allies and enemeies.
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    public void SelectPiece(int x, int y)
    {
        if (Pieces[x, y] == null)
            return;

        selectedPiece = Pieces[x, y];
    }

    /// <summary>
    /// Moves the posistion of the current piece.
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    public void MovePiece(int x, int y)
    {
        if (/*allowedMoves[x, y]*/ true)
        {
            Debug.Log("move piece to: " + x + " " + y);
            Pieces[currentPiece.CurrentX, currentPiece.CurrentY] = null;
            currentPiece.transform.position = GetTileCenter(x, y);
            currentPiece.SetPostion(x, y);
            Pieces[x, y] = currentPiece;

            GridHighlight.Instance.HideHighlights();
        }

        GridHighlight.Instance.HideHighlights();
        moveButtonSelected = false;
    }

    /// <summary>
    /// Draws the lines of the grid.
    /// </summary>
    private void DrawGrid()
    {
        Vector3 widthLine = Vector3.right * gridWidth;
        Vector3 heightLine = Vector3.forward * gridWidth;

        for (int i = 0; i <= gridWidth; i++)
        {
            Vector3 start = Vector3.forward * i;
            Debug.DrawLine(start, start + widthLine);
            for (int j = 0; j <= gridWidth; j++)
            {
                start = Vector3.right * j;
                Debug.DrawLine(start, start + heightLine);
            }
        }

        /// Da=raws the tile that the mouse is hoving over.
        if (selectionX >= 0 && selectionY >= 0)
        {
            Debug.DrawLine(
                Vector3.forward * selectionY + Vector3.right * selectionX,
                Vector3.forward * (selectionY + 1) + Vector3.right * (selectionX + 1));

            Debug.DrawLine(
            Vector3.forward * (selectionY + 1) + Vector3.right * selectionX,
            Vector3.forward * selectionY + Vector3.right * (selectionX + 1));
        }
    }
}
