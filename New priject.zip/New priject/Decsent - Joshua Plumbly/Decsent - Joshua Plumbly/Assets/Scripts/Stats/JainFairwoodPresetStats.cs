﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JainFairwoodPresetStats : BaseCharacterClass
{
    public JainFairwoodPresetStats()
    {
        CharacterName = "Jain Fairwood";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Scout;
        CharacterClass = enumCharacterClass.Error;
        Speed = 5;
        Health = 8;
        Stamina = 5;
        Defence = enumDefence.oneGrayDice;
        Might = 2;
        Knowledge = 3;
        Willpower = 2;
        Awareness = 4;
    }
}
