﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

public class XMLmanger : MonoBehaviour
{//https://www.youtube.com/watch?v=6vl1IYMpwVQ
    public static XMLmanger xmlman;
	// Use this for initialization
	void Awake () {
        xmlman = this;
	}

    public charsacterdatabase charerdateres;

    public void savecharacter()
    {
        XmlSerializer seriailler = new XmlSerializer(typeof(charsacterdatabase));
        FileStream stream = new FileStream(Application.dataPath+ "/Scripts/Stats/character.xml", FileMode.Create);
        seriailler.Serialize(stream, charerdateres);
        stream.Close();
    }
	public void loadcharacter()
    {
        XmlSerializer seriailler = new XmlSerializer(typeof(charsacterdatabase));
        FileStream stream = new FileStream(Application.dataPath + "/Scripts/Stats/character.xml", FileMode.Open);
        charerdateres = seriailler.Deserialize(stream) as charsacterdatabase;
        stream.Close();
    }
}
[System.Serializable]
public class characterEntry
{
    public string classname;
    public string classduson;
    public int playerheatfs;
    public int playerspeed;
    public int playerstamener;
    public int playermight;
    public int playerknowledge;
    public int playerwillpower;
    public int playerawarewness;
    public enumCharacterClass playerclass;
    public enumArchetypes playeracrchet;
    public enumDefence playerdefence;
}
[System.Serializable]
public class charsacterdatabase
{
    public List<characterEntry> characterentry = new List<characterEntry>();
    
}


public enum enumCharacterClass
{
    Error,

    // Scount
    ashrian,
    avric,
    /* BountyHunter,
     Monk,
     ShadowWalker,
     Stalker,
     Thief,
     TreasureHunter,
     Windlander,*/

    //Warrior
    grisban,
    syndrael,
    /*Beastmaster,
    Berserker,
    Champition,
    Knight,
    Marshal,
    Skirmisher,
    Steelcaster,*/

    // Mage
    leoric,
    widow,
    /*  Battlemage,
      Conjurer,
      Geomancer,
      Hexer,
      Necromancer,
      Runemaster,*/

    // Healler
    tomble,
    jain,
    /* Apothecary,
     Bard,
     Disciple,
     Prophet,
     Spitirspeaker,
     Watchman*/
};
[SerializeField]
public enum enumDefence
{
    oneGrayDice,
    oneBrownDice,
    oneBlackDice
};
public enum enumArchetypes
{
    Scout,
    Warrior,
    Mage,
    Healer
}

