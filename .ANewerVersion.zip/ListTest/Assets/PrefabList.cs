﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class PrefabList : MonoBehaviour {
    public List<Vector3> heroSpawnLocations;
    public List<GameObject> players;
    public GameObject Avric;
    public GameObject Tomble;
    public GameObject Grisban;
    public GameObject Tarha;
    public int playerCount;
    public GameObject currentHero;
    public AttackScript currentAttack;
    public bool isDone = false;
    public int pointer;
    public int lastPlayerId;

    public List<Vector3> monsterSpawnLocations;
    public List<GameObject> monsters;
    public GameObject currentMonster;
    public GameObject GoblinArcherLv1;
    public GameObject ZombieLv1;
    public GameObject ZombieLv2;
    public int pointer2;
    private void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
    void PlayerSpawn(ref GameObject playerSpawn)
    {
        GameObject reference;
        reference = Instantiate(playerSpawn, heroSpawnLocations[pointer], Quaternion.identity);
    }
    void MonsterSpawn(ref GameObject monsterSpawn)
    {
        GameObject reference;
        reference = Instantiate(monsterSpawn, monsterSpawnLocations[pointer2], Quaternion.identity);
    }
    private void Update()
    {
        if(SceneManager.GetActiveScene().buildIndex == 2)
        {

            if (isDone == false)
            {
                

                isDone = true;
                for (int i = 0; i < playerCount - 1; i++)
                {
                    pointer = i;
                    currentHero = players[i];
                    PlayerSpawn(ref currentHero);
                    currentAttack = currentHero.GetComponent<AttackScript>();
                    currentAttack.id = i;

                    print("Player id " + (currentAttack.id));
                    lastPlayerId = i+1;
                }
                for (int i = 0; i < playerCount + 1; i++)
                {
                    pointer2 = i;
                    currentMonster = monsters[i];
                    MonsterSpawn(ref currentMonster);
                    currentAttack = currentMonster.GetComponent<AttackScript>();
                    currentAttack.id = lastPlayerId + i;
                    print("Monster id " + (currentAttack.id));
                    //print("Monster " + (i) + " spawned");
                }

            }  
            
        }
        
    }
    public void TwoPlayers()
    {
        playerCount = 2;
        monsters.Add(GoblinArcherLv1);
        monsters.Add(ZombieLv1);
        monsters.Add(ZombieLv2);
        SceneManager.LoadScene(1, LoadSceneMode.Single);
    }
    public void ThreePlayers()
    {
        playerCount = 3;
        monsters.Add(GoblinArcherLv1);
        monsters.Add(ZombieLv1);
        monsters.Add(ZombieLv2);
        SceneManager.LoadScene(1, LoadSceneMode.Single);
    }
    public void FourPlayers()
    {
        playerCount = 4;
        monsters.Add(GoblinArcherLv1);
        monsters.Add(ZombieLv1);
        monsters.Add(ZombieLv2);
        SceneManager.LoadScene(1, LoadSceneMode.Single);
    }
    public void FivePlayers()
    {
        playerCount = 5;
        monsters.Add(GoblinArcherLv1);
        monsters.Add(ZombieLv1);
        monsters.Add(ZombieLv2);
        SceneManager.LoadScene(1, LoadSceneMode.Single);
    }
    

}
