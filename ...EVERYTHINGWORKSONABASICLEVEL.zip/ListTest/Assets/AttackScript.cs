﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackScript : MonoBehaviour {
    //If attack was already done
    public bool isDone = false;
    //Range of Attack 
    protected int range = 0;
    //Rolling
    public bool diceRoll = false;
    //So hit-ting it possible
    protected RaycastHit hit;
    //Damage of attack
    public int attack = 1;
    //Rolling the dice
    protected int dice;
    //check if in range only once
    protected bool isInRange = false;
    //Get Material
    protected Material m_Material;
    //Getting to GameMaster
    public GameObject gameManager;
    public PlayerScript gameScript;
    //Defensive Stats
    protected int defence = 0;
    protected int health = 3;
    protected int damageDealt = 0;
    public void Battle()
    {
        if (diceRoll == true)
        {
            if (isInRange == true)
            {
                Rays();
                EnemyInRange();
                isInRange = false;
            }
        }
        else
        {
            if (isInRange == false)
            {
                Rays();
                EnemyNotInRange();
                isInRange = true;
            }
        }
    }
    public void Diceroll()
    {

        //rolling dice to get results
        if (diceRoll == false)
        {
           
                if (Input.GetKeyDown(KeyCode.Keypad5))
                {
                    gameManager = GameObject.Find("GameManager");
                    gameScript = gameManager.GetComponent<PlayerScript>();
                    dice = Random.Range(0, 6);
                    switch (dice)
                    {
                        case 0:
                            range = 0;
                            attack = 0;
                            break;
                        case 1:
                            range = 2;
                            attack = 2;
                            break;
                        case 2:
                            range = 3;
                            attack = 2;
                            break;
                        case 3:
                            range = 4;
                            attack = 2;
                            break;
                        case 4:
                            range = 5;
                            attack = 1;
                            break;
                        case 5:
                            range = 6;
                            attack = 1;
                            break;
                    }
                    diceRoll = true;
                    Debug.Log(gameScript.currentPlayer + "rolled " + range + " for range.");
                    Debug.Log(gameScript.currentPlayer + "rolled " + attack + " for attack.");
                }
            }
            /*else
            {
                if (isDone == false)
                {
                    if (Input.GetKeyDown(KeyCode.Keypad5))
                    {

                    diceRoll = false;
                    range = 0;
                    attack = 0;
                    Debug.Log(gameScript.currentPlayer + "ended their turn");
                    isDone = true;
                    }
                }

            }*/
        
    }
    public void Rays()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));
        //Debugging that tells in console if the raycasts actually hit their intended targets
        if (diceRoll == true)
        {
            if (isDone == false)
            {
                Vector3 direction = Vector3.zero;

                if (Input.GetKeyDown(KeyCode.Keypad8))
                    direction = fwd;
                else if (Input.GetKeyDown(KeyCode.Keypad2))
                    direction = bck;
                else if (Input.GetKeyDown(KeyCode.Keypad4))
                    direction = lft;
                else if (Input.GetKeyDown(KeyCode.Keypad6))
                    direction = rgt;
                else if (Input.GetKeyDown(KeyCode.Keypad7))
                    direction = fwd_lft;
                else if (Input.GetKeyDown(KeyCode.Keypad9))
                    direction = fwd_rgt;
                else if (Input.GetKeyDown(KeyCode.Keypad1))
                    direction = bck_lft;
                else if (Input.GetKeyDown(KeyCode.Keypad3))
                    direction = bck_rgt;

                if (direction != Vector3.zero)
                {
                    if (Physics.Raycast(transform.position, direction, out hit, range) /*&& hit.transform.tag == "Player"*/)
                    {
                        isInRange = false;
                        //activates void in other object with the name "hit by ray"
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;

                    }
                }
            }
        }

    }
    public void EnemyInRange()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));

        if (Physics.Raycast(transform.position, fwd, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, lft, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, rgt, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, fwd_lft, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, fwd_rgt, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck_lft, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck_rgt, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
    }
    protected void EnemyNotInRange()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));

        if (Physics.Raycast(transform.position, fwd, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, fwd_lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, fwd_rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck_lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck_rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
    }

    public void NotInRange()
    {
        m_Material = GetComponent<Renderer>().material;
        m_Material.color = Color.white;
    }
    void InRange()
    {
        m_Material = GetComponent<Renderer>().material;
        // Change the Color of the GameObject when it is in range
        m_Material.color = Color.red;
    }
    void DefenceDiceRoll()
    {
        dice = Random.Range(0, 6);
        switch (dice)
        {
            case 0:
                defence = 0;
                break;
            case 1:
                defence = 1;
                break;
            case 2:
                defence = 1;
                break;
            case 3:
                defence = 1;
                break;
            case 4:
                defence = 2;
                break;
            case 5:
                defence = 3;
                break;
        }
        Debug.Log("I rolled " + defence + " points of defence");
    }
    /*void HitByRay()
    {
        DefenceDiceRoll();
        damageDealt =  //SCRIPT FROM OBJECT IT GETS SHOT FROM  .damage - defence;
        if (damageDealt <= 0)
        {
            damageDealt = 0;
        }
        Debug.Log("I was hit by a total of " + damageDealt + " damage");

        //Self-explanatory name to be honest
        health = health - damageDealt;
        Debug.Log("My total health after being hit is " + health + ".");
    }*/
}
