﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public static class Dice {

    // Use this for initialization
    public static int reddice()
    {
        int harts = 0;
        int diceside = 0;
       System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);
        switch(diceside)
        {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;

        }
        return harts;
            }
	public static int bluedice() {
        int range = 0;
        int diceside = 0;
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);
        switch (diceside)
        {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;

        }
        return range;
    }
    public static int browondice()
    {
        int shonid = 0;
        int diceside = 0;
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);
        switch (diceside)
        {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;

        }
        return shonid;
    }
    public static int granddice()
    {
        int shonid = 0;
        int diceside = 0;
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);
        switch (diceside)
        {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;

        }
        return shonid;
    }
    // Update is called once per frame

}
