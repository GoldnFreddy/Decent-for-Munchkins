﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieLv2 : PlayerStats {

	
}
