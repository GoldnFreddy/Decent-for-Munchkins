﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CaveSpiderLv2 : PlayerStats {

}
