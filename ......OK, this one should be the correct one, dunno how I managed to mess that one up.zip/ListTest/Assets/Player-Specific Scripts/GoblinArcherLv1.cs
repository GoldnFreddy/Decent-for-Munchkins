﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoblinArcherLv1 : PlayerStats {

	
}
