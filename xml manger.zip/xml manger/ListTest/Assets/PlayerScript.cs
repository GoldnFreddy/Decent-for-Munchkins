﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class PlayerScript : MonoBehaviour {
    public List<GameObject> players;// list of players
    public GameObject currentPlayer;
    public int pointer = 0;

    public bool playersGot = false;
    public bool monstersGot = false;
    public int firstMonster;

    public GameObject prefabMaster;
    public PrefabList prefabScript;

    public AttackScript fight;
    public MoveScript move;

    public int monstersDead;
    public int heroesOnExit;
    public int heroesDead;
    public bool someoneWon = false;
    

    public bool newTurn = false;
    public int actions = 2;
    //private void Awake()
    //{
    //    DontDestroyOnLoad(gameObject);
    //}
    // Use this for initialization
    /*void Start () {
        
        players.Add(GameObject.Find("Player1"));
        players.Add(GameObject.Find("Player2"));
        players.Add(GameObject.Find("Player3"));
        players.Add(GameObject.Find("Monster1"));
        players.Add(GameObject.Find("Monster2"));

    }*/
    private void Start()
    {
        prefabMaster = GameObject.Find("PrefabMaster");
        prefabScript = prefabMaster.GetComponent<PrefabList>();
    }
    void Turn()
    {
        
        if (pointer < (players.Count-1))
          {
            pointer++;
          }
        else
        {
            newTurn = true;
            pointer = 0;
            
        }   
            currentPlayer = players[pointer];
            actions = 2;
    }
	// Update is called once per frame
	void Update () {
            GetPlayers();
            GetMonsters();

            move = currentPlayer.GetComponent<MoveScript>();
            if (actions > 0)
            {
                move.Movement();
            }
            CheckWinConditions();
            fight = currentPlayer.GetComponent<AttackScript>();
            if (actions > 0)
            {
                fight.Diceroll();
                fight.Battle();
            }
            if (Input.GetKeyDown(KeyCode.Keypad5))
            {
           
                move.canMove = false;
                move.moveCounter = 0;
                actions -= 1;

            }
            if(Input.GetKeyDown(KeyCode.H))
            {
                if (actions > 0)
                {
                    fight.Rest();
                    actions -= 1;
                }
            }
            if (Input.GetKeyDown(KeyCode.Space))
            {
                
                fight.RefreshAttack();
                fight.NotInRange();
                print("From playerscript "+ players.Count);
                Turn();

                Debug.Log("It is now the turn of " + currentPlayer);
                move.RefreshMovement();

            }
            
    }
    //For choosing the amount of players in the Main Menu
    
    public void GetPlayers()
    {
        if (playersGot == false)
        {
            for (int i = 0; i < prefabScript.playerCount - 1; i++)
            {
                //players.Add(GameObject.Find("Avric(Clone)"));
                print(prefabScript.players[i].name.ToString() + "(Clone)");
                players.Add(GameObject.Find(prefabScript.players[i].name.ToString() + "(Clone)"));
                //currentPlayer = players[i];
                
                playersGot = true;
                pointer ++;
            }
            //firstMonster = pointer+1;
            //FOR TESTING REMOVE WHEN FINISHED
            /*Turn();
            Turn();
            Turn();
            Turn();*/
        }
    }
    public void GetMonsters()
    {
        if(monstersGot == false)
        {
            for (int i = 0; i < prefabScript.playerCount + prefabScript.differenceCount; i++)
            {
                //players.Add(GameObject.Find("Avric(Clone)"));
                print(prefabScript.monsters[i].name.ToString() + "(Clone)");
                players.Add(GameObject.Find(prefabScript.monsters[i].name.ToString() + "(Clone)"));
                
                monstersGot = true;
            }
            //currentPlayer = players[2];
            //pointer = firstMonster+1;
            currentPlayer = players[pointer];

        }
    }
    public void CheckWinConditions()
    {
        if (someoneWon == false)
        {
            if (heroesOnExit == prefabScript.playerCount - 1)
            {
                print("Heroes win!");
                someoneWon = true;
            }
            if (monstersDead == prefabScript.monsterCount)
            {
                print("Heroes win!");
                someoneWon = true;
            }
        }
    }
}
