﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class HeroButtonsScript : MonoBehaviour {
  
    public GameObject prefabManager;
    public PrefabList prefabScript;
    public int choiceCount = 1;
    void Start()//tis insplenst the perfab list
    {
        prefabManager = GameObject.Find("PrefabMaster");
        prefabScript = prefabManager.GetComponent<PrefabList>();
    }
    public void ChooseAvric()
    {
        //this is for choose avric 
        
            prefabScript.players.Add(prefabScript.Avric);
            choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)
        {
            
            SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
        }
    }
    public void ChooseGrisban()
    {
        //this is for choose grisban

        prefabScript.players.Add(prefabScript.Grisban);
            choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)// this load the level if all the have players select there game
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);
        }
    }
    public void ChooseTomble()
    { 
        //this is for choose Tomble
        prefabScript.players.Add(prefabScript.Tomble);
        choiceCount += 1; 
        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level 
        }
        
    }
    public void ChooseTarha()
    {//this is for choose Tarha
        prefabScript.players.Add(prefabScript.Tarha);
        choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
        }
    }
    public void ChooseLeoric()
    {//this is for choose Leoric
        prefabScript.players.Add(prefabScript.Leoric);
        choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
        }
    }
    public void ChooseAshrian()
    {//this is for choose Ashrian
        prefabScript.players.Add(prefabScript.Ashrian);
        choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
        }
    }
    public void ChooseJain()
    {//this is for choose Jain
        prefabScript.players.Add(prefabScript.Jain);
        choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
        }
    }
    public void ChooseSyndrael()
    {//this is for choose Syndrael
        prefabScript.players.Add(prefabScript.Syndrael);
        choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
        }
    }

}
