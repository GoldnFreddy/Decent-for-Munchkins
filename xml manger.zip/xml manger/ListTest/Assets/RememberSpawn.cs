﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RememberSpawn : MonoBehaviour {
    //public List<Transform> pos;
	void Awake () {
        
    }
    void Start()
    {
        //pos.Add();
    }
}
