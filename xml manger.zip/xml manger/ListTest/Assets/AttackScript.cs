﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class AttackScript : MonoBehaviour {
    //If attack was already done
    public bool isDone = false;
    //Range of Attack 
    protected int range = 0;
    //Rolling
    public bool diceRoll = false;
    //So hit-ting it possible
    protected RaycastHit hit;
    //Damage of attack
    public int attack = 1;
    //Rolling the dice
    protected int dice;
    //check if in range only once
    protected bool isInRange = false;
    //Get Material
    protected Material m_Material;
    //Getting to GameMaster
    public GameObject gameManager;
    public PlayerScript gameScript;
    //Getting Stats from character
    public PlayerStats attributes;
    //Defensive Stats
    public int defence = 0;
    public int health = 3;
    public int maxHealth;
    public int damageDealt = 0;
    public int attacked = 0;
    //Showing stuff in UI
    public Text showLog;
    //for reviving
    public int healthDiceResults;
    //for destroying
    public int id;
    //for players that are knocked out
    public bool isKnockedOut = false;
    //is reviving now
    public bool isReviving = false;

    private void Start()
    {
        showLog = GameObject.Find("AdventureLog").GetComponent<Text>();
        health = attributes.health;
        maxHealth = health;
       
        
        
    }

    public void Battle()
    {
        
        Rays();
        if (diceRoll == true)
        {
            if (isInRange == true)
            {
                
                EnemyInRange(); 
            }
            else
            {
                if (isInRange == false)
                {

                    EnemyNotInRange();
                    isInRange = true;
                }
            }
        }
        if (Input.GetKeyDown(KeyCode.R))
        { //this is for reviving the chatrare
            isReviving = true;
        }
        if(isReviving == true)
        {
            Revive();
            isReviving = false;
        }
        
    }
    public void Diceroll()
    {

        //rolling dice to get results
        if (diceRoll == false)
        {
           
                if (Input.GetKeyDown(KeyCode.Keypad5))
                {
                    gameManager = GameObject.Find("GameManager");
                    gameScript = gameManager.GetComponent<PlayerScript>();
                    AttackDiceType();
                    isDone = false;

                    diceRoll = true;
                    showLog.text = attributes.playerName  + " rolled " + range + " for range and " + attack + " for attack";
                    //Debug.Log(gameScript.currentPlayer + "rolled " + range + " for range.");
                    //Debug.Log(gameScript.currentPlayer + "rolled " + attack + " for attack.");
                }
            }
            /*else
            {
                if (isDone == false)
                {
                    if (Input.GetKeyDown(KeyCode.Keypad5))
                    {

                    diceRoll = false;
                    range = 0;
                    attack = 0;
                    Debug.Log(gameScript.currentPlayer + "ended their turn");
                    isDone = true;
                    }
                }

            }*/
        
    }
    void AttackDiceType()
    {
        switch (attributes.attackDiceType)
        {
            case "BlueYellow":
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        range = 0;
                        attack = 0;
                        break;
                    case 1:
                        range = 2;
                        attack = 2;
                        break;
                    case 2:
                        range = 3;
                        attack = 2;
                        break;
                    case 3:
                        range = 4;
                        attack = 2;
                        break;
                    case 4:
                        range = 5;
                        attack = 1;
                        break;
                    case 5:
                        range = 6;
                        attack = 1;
                        break;
                }
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        attack += 0;
                        break;
                    case 1:
                        attack += 1;
                        break;
                    case 2:
                        attack += 1;
                        break;
                    case 3:
                        attack += 1;
                        break;
                    case 4:
                        attack += 2;
                        break;
                    case 5:
                        attack += 2;
                        break;
                }
                break;
            case "BlueYellowMelee":
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        range = 0;
                        attack = 0;
                        break;
                    case 1:
                        range = 1;
                        attack = 2;
                        break;
                    case 2:
                        range = 1;
                        attack = 2;
                        break;
                    case 3:
                        range = 1;
                        attack = 2;
                        break;
                    case 4:
                        range = 1;
                        attack = 1;
                        break;
                    case 5:
                        range = 1;
                        attack = 1;
                        break;
                }
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        attack += 0;
                        break;
                    case 1:
                        attack += 1;
                        break;
                    case 2:
                        attack += 1;
                        break;
                    case 3:
                        attack += 1;
                        break;
                    case 4:
                        attack += 2;
                        break;
                    case 5:
                        attack += 2;
                        break;
                }
                break;
            case "BlueYellowYellowMelee":
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        range = 0;
                        attack = 0;
                        break;
                    case 1:
                        range = 1;
                        attack = 2;
                        break;
                    case 2:
                        range = 1;
                        attack = 2;
                        break;
                    case 3:
                        range = 1;
                        attack = 2;
                        break;
                    case 4:
                        range = 1;
                        attack = 1;
                        break;
                    case 5:
                        range = 1;
                        attack = 1;
                        break;
                }
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        attack += 0;
                        break;
                    case 1:
                        attack += 1;
                        break;
                    case 2:
                        attack += 1;
                        break;
                    case 3:
                        attack += 1;
                        break;
                    case 4:
                        attack += 2;
                        break;
                    case 5:
                        attack += 2;
                        break;
                }
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        attack += 0;
                        break;
                    case 1:
                        attack += 1;
                        break;
                    case 2:
                        attack += 1;
                        break;
                    case 3:
                        attack += 1;
                        break;
                    case 4:
                        attack += 2;
                        break;
                    case 5:
                        attack += 2;
                        break;
                }
                break;
            case "BlueRedMelee":
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        range = 0;
                        attack = 0;
                        break;
                    case 1:
                        range = 1;
                        attack = 2;
                        break;
                    case 2:
                        range = 1;
                        attack = 2;
                        break;
                    case 3:
                        range = 1;
                        attack = 2;
                        break;
                    case 4:
                        range = 1;
                        attack = 1;
                        break;
                    case 5:
                        range = 1;
                        attack = 1;
                        break;
                }
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        attack += 1;
                        break;
                    case 1:
                        attack += 2;
                        break;
                    case 2:
                        attack += 2;
                        break;
                    case 3:
                        attack += 2;
                        break;
                    case 4:
                        attack += 3;
                        break;
                    case 5:
                        attack += 3;
                        break;
                }
                break;
        }
    }
    public void Rays()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));
        //Debugging that tells in console if the raycasts actually hit their intended targets
        if (diceRoll == true)
        {
            if (isDone == false)
            {
                Vector3 direction = Vector3.zero;

                if (Input.GetKeyDown(KeyCode.Keypad8))
                    direction = fwd;
                else if (Input.GetKeyDown(KeyCode.Keypad2))
                    direction = bck;
                else if (Input.GetKeyDown(KeyCode.Keypad4))
                    direction = lft;
                else if (Input.GetKeyDown(KeyCode.Keypad6))
                    direction = rgt;
                else if (Input.GetKeyDown(KeyCode.Keypad7))
                    direction = fwd_lft;
                else if (Input.GetKeyDown(KeyCode.Keypad9))
                    direction = fwd_rgt;
                else if (Input.GetKeyDown(KeyCode.Keypad1))
                    direction = bck_lft;
                else if (Input.GetKeyDown(KeyCode.Keypad3))
                    direction = bck_rgt;

                if (direction != Vector3.zero)
                {
                    if (attributes.isHero == false)
                    {
                        if (Physics.Raycast(transform.position, direction, out hit, range) && hit.transform.tag == "Player")
                        {

                            //activates void in other object with the name "hit by ray"
                            hit.transform.GetComponent<AttackScript>().attacked = attack;
                            hit.transform.SendMessage("HitByRay");
                            isInRange = false;
                            isDone = true;
                            range = 0;

                        }
                    }
                    else if (attributes.isHero == true)
                    {
                        if (Physics.Raycast(transform.position, direction, out hit, range) && hit.transform.tag == "Monster")
                        {

                            //activates void in other object with the name "hit by ray"
                            hit.transform.GetComponent<AttackScript>().attacked = attack;
                            hit.transform.SendMessage("HitByRay");
                            isInRange = false;
                            isDone = true;
                            range = 0;

                        }
                    }
                }
            }
        }

    }
    public void EnemyInRange()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));
        if (attributes.isHero == false)
        {
            if (Physics.Raycast(transform.position, fwd, out hit, range) && hit.transform.tag == "Player")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
        else if (attributes.isHero == true)
        {
            if (Physics.Raycast(transform.position, fwd, out hit, range) && hit.transform.tag == "Monster")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }

        if (attributes.isHero == false)
        {
            if (Physics.Raycast(transform.position, bck, out hit, range) && hit.transform.tag == "Player")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
        else if (attributes.isHero == true)
        {
            if (Physics.Raycast(transform.position, bck, out hit, range) && hit.transform.tag == "Monster")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }

        if (attributes.isHero == false)
        {
            if (Physics.Raycast(transform.position,lft, out hit, range) && hit.transform.tag == "Player")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
        else if (attributes.isHero == true)
        {
            if (Physics.Raycast(transform.position, lft, out hit, range) && hit.transform.tag == "Monster")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }

        if (attributes.isHero == false)
        {
            if (Physics.Raycast(transform.position, rgt, out hit, range) && hit.transform.tag == "Player")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
        else if (attributes.isHero == true)
        {
            if (Physics.Raycast(transform.position, rgt, out hit, range) && hit.transform.tag == "Monster")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }

        if (attributes.isHero == false)
        {
            if (Physics.Raycast(transform.position, fwd_lft, out hit, range) && hit.transform.tag == "Player")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
        else if (attributes.isHero == true)
        {
            if (Physics.Raycast(transform.position, fwd_lft, out hit, range) && hit.transform.tag == "Monster")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }

        if (attributes.isHero == false)
        {
            if (Physics.Raycast(transform.position, fwd_rgt, out hit, range) && hit.transform.tag == "Player")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
        else if (attributes.isHero == true)
        {
            if (Physics.Raycast(transform.position, fwd_rgt, out hit, range) && hit.transform.tag == "Monster")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }

        if (attributes.isHero == false)
        {
            if (Physics.Raycast(transform.position, bck_lft, out hit, range) && hit.transform.tag == "Player")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
        else if (attributes.isHero == true)
        {
            if (Physics.Raycast(transform.position, bck_lft, out hit, range) && hit.transform.tag == "Monster")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }

        if (attributes.isHero == false)
        {
            if (Physics.Raycast(transform.position, bck_rgt, out hit, range) && hit.transform.tag == "Player")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
        else if (attributes.isHero == true)
        {
            if (Physics.Raycast(transform.position, bck_rgt, out hit, range) && hit.transform.tag == "Monster")
            {
                isInRange = true;
                hit.transform.SendMessage("InRange");
            }
        }
    }
    protected void EnemyNotInRange()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));

        if (Physics.Raycast(transform.position, fwd, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, fwd_lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, fwd_rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck_lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck_rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
    }

    public void NotInRange()
    {
        m_Material = GetComponent<Renderer>().material;
        m_Material.color = Color.white;
    }
    void InRange()
    {
        m_Material = GetComponent<Renderer>().material;
        // Change the Color of the GameObject when it is in range
        m_Material.color = Color.red;
    }
    void DefenceDiceRoll()
    {
        DefenceDiceType();
        Debug.Log("I rolled " + defence + " points of defence");
    }
    void DefenceDiceType()
    {
        switch (attributes.defenceDiceType)
        {
            case "Grey":
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        defence = 0;
                        break;
                    case 1:
                        defence = 1;
                        break;
                    case 2:
                        defence = 1;
                        break;
                    case 3:
                        defence = 1;
                        break;
                    case 4:
                        defence = 2;
                        break;
                    case 5:
                        defence = 3;
                        break;
                }
                break;


            case "Brown":
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        defence = 0;
                        break;
                    case 1:
                        defence = 0;
                        break;
                    case 2:
                        defence = 0;
                        break;
                    case 3:
                        defence = 1;
                        break;
                    case 4:
                        defence = 1;
                        break;
                    case 5:
                        defence = 2;
                        break;
                }
                break;
            case "GreyBrown":
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        defence = 0;
                        break;
                    case 1:
                        defence = 1;
                        break;
                    case 2:
                        defence = 1;
                        break;
                    case 3:
                        defence = 1;
                        break;
                    case 4:
                        defence = 2;
                        break;
                    case 5:
                        defence = 3;
                        break;
                }
                dice = Random.Range(0, 6);
                switch (dice)
                {
                    case 0:
                        defence += 0;
                        break;
                    case 1:
                        defence += 1;
                        break;
                    case 2:
                        defence += 1;
                        break;
                    case 3:
                        defence += 1;
                        break;
                    case 4:
                        defence += 2;
                        break;
                    case 5:
                        defence += 3;
                        break;
                }
                break;
        }
    }
    void HitByRay()
    {
        DefenceDiceRoll();
        damageDealt = attacked - defence;
        if (damageDealt <= 0)
        {
            damageDealt = 0;
        }
        Debug.Log(attributes.playerName +" was hit for a total of " + damageDealt + " damage");

        //Self-explanatory name to be honest
        health = health - damageDealt;
        Debug.Log(attributes.playerName + " total health after being hit is " + health + ".");
        showLog.text = attributes.playerName +" rolled " + defence.ToString() + " points of defence, was hit for a total of " + damageDealt.ToString() + " and now my health is " + health.ToString() + " HP";
        if (health <= 0)
        {
            //showLog.text = "Overlord Wins!";

            if (attributes.isHero == false)
            {
                transform.Translate(0, -5, 0);
                print(id);
                gameManager = GameObject.Find("GameManager");
                gameScript = gameManager.GetComponent<PlayerScript>();
                print(gameScript.players.Count);
                gameScript.players.RemoveAt(id);
                gameScript.monstersDead += 1;
            }
            if (attributes.isHero == true)
            {
                gameManager = GameObject.Find("GameManager");
                gameScript = gameManager.GetComponent<PlayerScript>();
                gameScript.actions = 0;
                if (isKnockedOut == false)
                {
                    gameScript.heroesDead += 1;
                    isKnockedOut = true;
                }
            }
        }
        else
        {
            isKnockedOut = false;
        }
        
    }
    public void RefreshAttack()
    {
        isDone = false;
        range = 0;
        diceRoll = false;
        isInRange = false;
        transform.GetChild(0).gameObject.SetActive(true);
    }
    public void GetAttributes()
    {
        attributes = GetComponent<PlayerStats>();
    }

    public void Rest()
    {
        dice = Random.Range(0, 6);
        switch (dice)
        {
            case 0:
                health += 1;
                showLog.text = attributes.playerName + " healed for " + 1 + " health";
                break;
            case 1:
                health += 2;
                showLog.text = attributes.playerName + " healed for " + 2 + " health";
                break;
            case 2:
                health += 2;
                showLog.text = attributes.playerName + " healed for " + 2 + " health";
                break;
            case 3:
                health += 2;
                showLog.text = attributes.playerName + " healed for " + 2 + " health";
                break;
            case 4:
                health += 3;
                showLog.text = attributes.playerName + " healed for " + 3 + " health";
                break;
            case 5:
                health += 3;
                showLog.text = attributes.playerName + " healed for " + 3 + " health";
                break;
        }
        if(health > maxHealth)
        {
            health = maxHealth;
        }
    }
    public void RollForRevive()
    {
        dice = Random.Range(0, 6);
        switch (dice)
        {
            case 0:
                healthDiceResults += 1;              
                break;
            case 1:
                healthDiceResults += 2;
                break;
            case 2:
                healthDiceResults += 2;
                break;
            case 3:
                healthDiceResults += 2; 
                break;
            case 4:
                healthDiceResults += 3;  
                break;
            case 5:
                healthDiceResults += 3;
                break;
        }
        dice = Random.Range(0, 6);
        switch (dice)
        {
            case 0:
                healthDiceResults += 1;
                break;
            case 1:
                healthDiceResults += 2;
                break;
            case 2:
                healthDiceResults += 2;
                break;
            case 3:
                healthDiceResults += 2;
                break;
            case 4:
                healthDiceResults += 3;
                break;
            case 5:
                healthDiceResults += 3;
                break;
        }
    }
    public void Revive()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));
        //Debugging that tells in console if the raycasts actually hit their intended targets
       
                Vector3 direction = Vector3.zero;

                if (Input.GetKeyDown(KeyCode.Keypad8))
                    direction = fwd;
                else if (Input.GetKeyDown(KeyCode.Keypad2))
                    direction = bck;
                else if (Input.GetKeyDown(KeyCode.Keypad4))
                    direction = lft;
                else if (Input.GetKeyDown(KeyCode.Keypad6))
                    direction = rgt;
                else if (Input.GetKeyDown(KeyCode.Keypad7))
                    direction = fwd_lft;
                else if (Input.GetKeyDown(KeyCode.Keypad9))
                    direction = fwd_rgt;
                else if (Input.GetKeyDown(KeyCode.Keypad1))
                    direction = bck_lft;
                else if (Input.GetKeyDown(KeyCode.Keypad3))
                    direction = bck_rgt;

                if (direction != Vector3.zero)
                {
                    if (attributes.isHero == true)
                    {
                        if (Physics.Raycast(transform.position, direction, out hit, 1) && hit.transform.tag == "Player")
                        {

                            //activates void in other object with the name "hit by ray"
                            if(hit.transform.GetComponent<AttackScript>().health <= 0)
                            {
                                hit.transform.GetComponent<AttackScript>().health += healthDiceResults;
                                showLog.text = attributes.playerName + " healed" + hit.transform.name + " for " + healthDiceResults + " health";
                            }

                            isInRange = false;
                            

                        }
                    }
                    
                }
            
        

    }
}
