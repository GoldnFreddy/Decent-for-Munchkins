﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class MoveScript : MonoBehaviour {
    RaycastHit hit;
    public int moveCounter = 0;
    //Getting Stats from character
    public PlayerStats attributes;
    //Send stuff to manager
    public GameObject gameManager;
    public PlayerScript gameScript;
    //Can the player move?
    public bool canMove = true;
    //Showing stuff in UI
    public Text showSpeed;
    //also for showing stuff in UI
    public int movesLeft;
    //Is the player standing on the exit
    public bool onExit = false;

    public void Start()
    {
        transform.GetChild(0).gameObject.SetActive(true);
        showSpeed = GameObject.Find("AdventureLog").GetComponent<Text>();
        gameManager = GameObject.Find("GameManager");
        gameScript = gameManager.GetComponent<PlayerScript>();
    }
    // Update is called once per frame
    public void Movement () {
        if (canMove == true)
        {
            movesLeft = attributes.speed - moveCounter;
            showSpeed.text = attributes.playerName +" has " + movesLeft.ToString() + " moves left";
            transform.GetChild(0).gameObject.SetActive(false);
            if (attributes.overlordSetup == false)
            {
                if (moveCounter >= attributes.speed)
                {
                    showSpeed.text = "You are out of moves!";
                    canMove = false;
                    moveCounter = 0;
                }
            }

            Vector3 dwn = transform.TransformDirection(Vector3.down);
            //Player Movement
            if (Input.GetKeyDown(KeyCode.Keypad8))
            {
                //transform.parent = null;
                transform.Translate(0, 0, 1);
                moveCounter += 1;
                //check for ground
                if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                {
                    Hero();
                }
                else
                {
                    moveCounter -= 1;
                    transform.Translate(0, 0, -1);
                }
            }
            else if (Input.GetKeyDown(KeyCode.Keypad2))
            {
                //transform.parent = null;
                transform.Translate(0, 0, -1);
                moveCounter += 1;
                if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                {
                    Hero();
                }
                else
                {
                    moveCounter -= 1;
                    transform.Translate(0, 0, 1);
                }
            }
            else if (Input.GetKeyDown(KeyCode.Keypad4))
            {
                transform.Translate(-1, 0, 0);
                moveCounter += 1;
                if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                {
                    Hero();
                }
                else
                {
                    moveCounter -= 1;
                    transform.Translate(1, 0, 0);
                }
            }
            else if (Input.GetKeyDown(KeyCode.Keypad6))
            {
                transform.Translate(1, 0, 0);
                moveCounter += 1;
                if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                {
                    Hero();
                }
                else
                {
                    moveCounter -= 1;
                    transform.Translate(-1, 0, 0);
                }
            }
            else if (Input.GetKeyDown(KeyCode.Keypad7))
            {
                transform.Translate(-1, 0, 1);
                moveCounter += 1;
                if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                {
                    Hero();
                }
                else
                {
                    moveCounter -= 1;
                    transform.Translate(1, 0, -1);
                }
            }
            else if (Input.GetKeyDown(KeyCode.Keypad9))
            {
                transform.Translate(1, 0, 1);
                moveCounter += 1;
                if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                {
                    Hero();
                }
                else
                {
                    moveCounter -= 1;
                    transform.Translate(-1, 0, -1);
                }
            }
            else if (Input.GetKeyDown(KeyCode.Keypad1))
            {
                transform.Translate(-1, 0, -1);
                moveCounter += 1;
                if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                {
                    Hero();
                }
                else
                {
                    moveCounter -= 1;
                    transform.Translate(1, 0, 1);
                }
            }
            else if (Input.GetKeyDown(KeyCode.Keypad3))
            {
                transform.Translate(1, 0, -1);
                moveCounter += 1;
                if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Ground"))
                {
                    Hero();
                }
                else
                {
                    moveCounter -= 1;
                    transform.Translate(-1, 0, 1);
                }
            }
        }
    }
    public void RefreshMovement()
    {
        canMove = true;
        attributes.overlordSetup = false;
        moveCounter = 0;
    }
    public void GetAttributes()
    {
        attributes = GetComponent<PlayerStats>();
    }
    void Hero()
    {
        Vector3 dwn = transform.TransformDirection(Vector3.down);
        if (attributes.isHero==true)
        {
            if (Physics.Raycast(transform.position, dwn, out hit, 1) && hit.transform.tag.Contains("Win"))
            {
                if (onExit == false)
                {
                    gameScript.heroesOnExit += 1;
                    onExit = true;
                }
            }
            else
            {
                if (onExit == true)
                {
                    gameScript.heroesOnExit -= 1;
                    onExit = false;
                }
            }
        }
    }
}
