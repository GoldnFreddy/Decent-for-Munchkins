﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WidowTarhaPresetStats : BaseCharacterClass
{
    public WidowTarhaPresetStats()
    {
        CharacterName = "Widow Tarha";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Mage;
        CharacterClass = enumCharacterClass.Error;
        Speed = 4;
        Health = 10;
        Stamina = 4;
        Defence = enumDefence.oneGrayDice;
        Might = 2;
        Knowledge = 4;
        Willpower = 3;
        Awareness = 2;
    }
}
