﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrisbanTheThirstyPresetStats : BaseCharacterClass
{
    public GrisbanTheThirstyPresetStats()
    {
        CharacterName = "Grisban the Thirsty";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Warrior;
        CharacterClass = enumCharacterClass.Error;
        Speed = 3;
        Health = 14;
        Stamina = 4;
        Defence = enumDefence.oneGrayDice;
        Might = 5;
        Knowledge = 2;
        Willpower = 3;
        Awareness = 1;
    }
}
