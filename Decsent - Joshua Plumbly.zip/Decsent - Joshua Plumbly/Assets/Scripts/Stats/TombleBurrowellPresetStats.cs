﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TombleBurrowellPresetStats : BaseCharacterClass
{
    public TombleBurrowellPresetStats()
    {
        CharacterName = "Tomble Burrowell";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Scout;
        CharacterClass = enumCharacterClass.Error;
        Speed = 4;
        Health = 8;
        Stamina = 5;
        Defence = enumDefence.oneGrayDice;
        Might = 1;
        Knowledge = 2;
        Willpower = 3;
        Awareness = 5;
    }
}
