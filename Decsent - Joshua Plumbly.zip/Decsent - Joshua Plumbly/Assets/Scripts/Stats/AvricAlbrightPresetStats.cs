﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AvricAlbrightPresetStats : BaseCharacterClass
{
    public AvricAlbrightPresetStats()
    {
        CharacterName = "Avric Albright";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Healer;
        CharacterClass = enumCharacterClass.Error;
        Speed = 4;
        Health = 12;
        Stamina = 4;
        Defence = enumDefence.oneGrayDice;
        Might = 2;
        Knowledge = 3;
        Willpower = 4;
        Awareness = 2;
    }
}
