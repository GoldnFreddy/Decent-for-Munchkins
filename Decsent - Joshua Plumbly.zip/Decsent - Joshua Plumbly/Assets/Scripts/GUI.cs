﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GUI : MonoBehaviour {

    private BaseCharacterClass class1 = new JainFairwoodPresetStats();

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnGUI()
    {
        GUILayout.Label(class1.CharacterName);
        GUILayout.Label(class1.CharacterDescription);
    }
}
