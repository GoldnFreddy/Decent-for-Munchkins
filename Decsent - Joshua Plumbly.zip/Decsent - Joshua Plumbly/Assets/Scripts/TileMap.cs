﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Type: Youtube Video Playlist, Title: Unity 3D Tuorial: Tile Maps, Publisher: quill18creates. 
// Part 2: https://www.youtube.com/watch?v=haelMvLyqDQ&t=90s
// Part 3: https://www.youtube.com/watch?v=ou3uwaJGJUc&t=0s&pbjreload=10

[ExecuteInEditMode]
[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshCollider))]
[RequireComponent(typeof(MeshRenderer))]

public class TileMap : MonoBehaviour {
    
    public int sizeX = 13; //This number shows the width of the grid.
    public int sizeZ = 12; // This shows the height of the grid.
    public float tilesize = 1.0f; // This is the size of each tile.
    
    // Use this for initialization
    void Start ()
    {
        BuildMesh();
    }

    void BuildMesh() // This function is to build the grid. 
    {

        int numTiles = sizeX * sizeZ;
        int numTris = numTiles * 2; // This calculates the number of triangles in the grid.

        int vSizeX = sizeX + 1; // This calculates how many X vectors there are
        int vSizeZ = sizeZ + 1; // This caculates how many Z vectors
        int numvertices = vSizeZ * vSizeX; // This calculates the amount of vectors in total.

        // Generate the mesh data.
        Vector3[] vertices = new Vector3[numvertices]; // This is an array of vectors which enables the grid can be built.
        Vector3[] normals = new Vector3[numvertices];
        Vector2[] uv = new Vector2[numvertices]; // This stores the position of each tile on the material.

        int[] triangles = new int[numTris * 3]; // This array stores the number position of each triangle.

        int x, z;
        for (z = 0; z < vSizeZ; z++)
        { // This loop is for constructing each row. 
            for (x = 0; x < vSizeX; x++)
            { // This loop is constructing each tile on a row. 
                vertices[z * vSizeX + x] = new Vector3(x * tilesize, 0, z * tilesize); // This calculates the position of each vector.
                normals[z * vSizeX + x] = Vector3.up; // This makes sure that all of the tiles are facing upwards.
                uv[z * vSizeX + x] = new Vector2((float)x / vSizeX, (float)z / vSizeZ); // This calculates the position of each tile on the material.
            }
        }
        Debug.Log("Done Vectors");


        for (z = 0; z < vSizeZ; z++)
        {
            for (x = 0; x < vSizeX; x++)
            { // This loop is for creating two triangles on each tile.
                int squareIndex = z * sizeX + x; // This calculates which tile the loop is on.  
                int triOffset = squareIndex * 5; // This calculates which position the triangles are placed with the array.
                // This constructs the first triangle on each tile. 
                triangles[triOffset + 0] = z * vSizeX + x + 0;
                triangles[triOffset + 1] = z * vSizeX + x + vSizeX + 0;
                triangles[triOffset + 2] = z * vSizeX + x + vSizeX + 1;
                // This constructs the second trianle on each tile.
                triangles[triOffset + 3] = z * vSizeX + x + 0;
                triangles[triOffset + 4] = z * vSizeX + x + vSizeX + 1;
                triangles[triOffset + 5] = z * vSizeX + x + 1;
            }
        }
        Debug.Log("Complated Triangles");

        //Create a new Mesh and populate with he data.
        Mesh mesh = new Mesh(); // This initialises the mesh.
        mesh.vertices = vertices; // This makes the mesh vertices equal the amount of vertices which were created.
        mesh.triangles = triangles; // This makes the mesh triangles equal the amont of triangles which were created.
        mesh.normals = normals; // This makes the mesh normals equal the amount of normals which were created.
        mesh.uv = uv; // This makes sure that the material can be displayed on the mesh.

        // Assign out mesh to out filter/render/collider.
        MeshFilter meshFilter = GetComponent<MeshFilter>(); // This creates the mesh in Unity.
        MeshRenderer meshRender = GetComponent<MeshRenderer>(); // This makes sure that the mesh is displayed. 
        MeshCollider meshCollier = GetComponent<MeshCollider>(); // This makes sure that the mesh can be collided with.

        meshFilter.mesh = mesh;
        Debug.Log("Compleated Mesh.");
    }
}
