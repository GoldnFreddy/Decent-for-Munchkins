﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BaseCharacterClass))]

public class HeroPiece : Piece {

    [SerializeField] private BaseCharacterClass CharacterClass;

    public void Start()
    {
        CharacterClass = this.GetComponent<BaseCharacterClass>();
        NullCheckComponents();
    }

    /// This funcion checks that components have been recived from the 'GetComponent'.
    /// If any of the components have come througe this funcion with idety any null refrances and display any errors in the debug menu.
    public void NullCheckComponents()
    {
        if (CharacterClass == null)
        {
            Debug.LogError(this.name + " can not find a suitable HeroStats class.");
        }
    }

    public override bool[,] PossibleMove()
    {
        bool[,] r = new bool[13, 13];

        Piece p;
        int i;

        ///RIGHT
        i = CurrentX;
        while (true)
        {
            i++;
            if (i >= 13 || i > CurrentX + CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[i, CurrentY];
            if (p == null)
                r[i, CurrentY] = true;
            else
                break;
        }

        ///LEFT
        i = CurrentX;
        while (true)
        {
            i--;
            if (i < 0 || i < CurrentX - CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[i, CurrentY];
            if (p == null)
                r[i, CurrentY] = true;
            else
                break;
        }

        ///UP
        i = CurrentY;
        while (true)
        {
            i++;
            if (i >= 13 || i > CurrentY + CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[CurrentX, i];
            if (p == null|| i > CurrentX + CharacterClass.Speed)
                r[CurrentX, i] = true;
            else
                break;
        }

        ///DWON
        i = CurrentY;
        while (true)
        {
            i--;
            if (i < 0 || i < CurrentY - CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[CurrentX, i];
            if (p == null)
                r[CurrentX, i] = true;
            else
                break;
        }

        //r[10, 10] = true;
        return r;
    }
}
