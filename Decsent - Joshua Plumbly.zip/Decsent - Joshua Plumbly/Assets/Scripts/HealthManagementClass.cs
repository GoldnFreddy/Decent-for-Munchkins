﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BaseCharacterClass))]

public class HealthManagementClass : MonoBehaviour
{
    [SerializeField] private int heathPoints;
    [SerializeField] private bool isknockedOut;
    [SerializeField] private BaseCharacterClass CharacterClass;

    public void Start()
    {
        CharacterClass = this.GetComponent<BaseCharacterClass>();
        NullCheckComponents();
    }

    /// This funcion checks that components have been recived from the 'GetComponent'.
    /// If any of the components have come througe this funcion with idety any null refrances and display any errors in the debug menu.
    public void NullCheckComponents()
    {
        if (CharacterClass == null)
        {
            Debug.LogError(this.name + " can not find a suitable HeroStats class.");
        }
    }

    public int HealthPoints
    {
        get { return heathPoints; }
        set { heathPoints = value; }
    }

    public void TakeDamage(int damage)
    {
        HealthPoints -= damage;
    }

    public void Heal(int heal)
    {
        HealthPoints += heal;
    }

    public void CheckHealth()
    {
        if (HealthPoints <= 0)
        {
            isknockedOut = true;
        }
        else
        {
            isknockedOut = false;
        }
    }
}
