﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public static class Dice {

    // Use this for initialization
    public static int reddice() //this is funion is for the red dices
    {
        int harts = 0; // this stort harts
        int diceside = 0;// this storts the diceside
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);//this picks a radom number from 0 to 5
        switch(diceside)//this tarnst side to hareats
        {
            case 0:
                harts = 1;
                break;
            case 1:
                harts = 2;
                break;
            case 2:
                harts = 2;
                break;
            case 3:
                harts = 3;
                break;
            case 4:
                harts = 2;
                break;
            case 5:
                harts = 3;
                break;

        }
        return harts;// this retuns the heats
            }
	public static int bluedice()//this is funion is for the blue  dices
    {
        int range = 0;// this stort range
        int diceside = 0;// this storts the diceside
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);//this picks a radom number from 0 to 5
        switch (diceside)//this tarnst side to hareats
        {
            case 0:
                range = 0;
                break;
            case 1:
                range = 2;
                break;
            case 2:
                range = 4;
                break;
            case 3:
                range = 6;
                break;
            case 4:
                range = 3;
                break;
            case 5:
                range = 5;
                break;

        }
        return range;// this retuns the range
    }
    public static int browondice()//this is funion is for the browon  dices
    {
        int shonid = 0;//this stort shonids
        int diceside = 0;//this storts the diceside
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);//this picks a radom number from 0 to 5
        switch (diceside)
        {
            case 0:
                shonid = 0;
                break;
            case 1:
                shonid = 1;
                break;
            case 2:
                shonid = 1;
                break;
            case 3:
                shonid = 0;
                break;
            case 4:
                shonid = 0;
                break;
            case 5:
                shonid = 2;
                break;

        }
        return shonid;// this retuns the heats
    }
    public static int granddice()
    {
        int shonid = 0;//this stort shonid
        int diceside = 0;// this storts the diceside
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);//this picks a radom number from 0 to 5
        switch (diceside)
        {
            case 0:
                shonid = 0;
                break;
            case 1:
                shonid = 1;
                break;
            case 2:
                shonid = 1;
                break;
            case 3:
                shonid = 1;
                break;
            case 4:
                shonid = 3;
                break;
            case 5:
                shonid = 2;
                break;

        }
        return shonid;// this retuns the shonid
    }
    public static int blackdice()
    {
        int shonid = 0;//this stort shonid
        int diceside = 0;// this storts the diceside
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);//this picks a radom number from 0 to 5
        switch (diceside)
        {
            case 0:
                shonid = 0;
                break;
            case 1:
                shonid = 2;
                break;
            case 2:
                shonid = 2;
                break;
            case 3:
                shonid = 2;
                break;
            case 4:
                shonid = 3;
                break;
            case 5:
                shonid = 4;
                break;

        }
        return shonid;// this retuns the shonid
    }
    public static int yellowdice()
    {
        int harts = 0;// this stort harts
        int diceside = 0;// this storts the diceside
        System.Random ran = new System.Random();
        diceside = ran.Next(0, 6);//this picks a radom number from 0 to 5
        switch (diceside)
        {
            case 0:
                harts = 0;
                break;
            case 1:
                harts = 1;
                break;
            case 2:
                harts = 2;
                break;
            case 3:
                harts = 1;
                break;
            case 4:
                harts = 1;
                break;
            case 5:
                harts = 2;
                break;

        }
        return harts;// this retuns the heats
    }
    // Update is called once per frame

}
