﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnManager : MonoBehaviour
{
    [SerializeField] private int movesLeft;
    [SerializeField] private bool isHero;

    

}
