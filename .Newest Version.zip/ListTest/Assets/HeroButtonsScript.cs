﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class HeroButtonsScript : MonoBehaviour {
  
    public GameObject prefabManager;
    public PrefabList prefabScript;
    public int choiceCount = 1;
    void Start()
    {
        prefabManager = GameObject.Find("PrefabMaster");
        prefabScript = prefabManager.GetComponent<PrefabList>();
    }
    public void ChooseAvric()
    {
        
        
            prefabScript.players.Add(prefabScript.Avric);
            choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)
        {
            
            SceneManager.LoadScene(2, LoadSceneMode.Single);
        }
    }
    public void ChooseGrisban()
    {
        
        
            prefabScript.players.Add(prefabScript.Grisban);
            choiceCount += 1;
        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);
        }
    }
    public void ChooseTomble()
    {
        prefabScript.players.Add(prefabScript.Tomble);
        choiceCount += 1; 
        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);
        }   
    }
    public void ChooseTarha()
    {
        
        
            prefabScript.players.Add(prefabScript.Tarha);
            choiceCount += 1;

        if (choiceCount == prefabScript.playerCount)
        {
            SceneManager.LoadScene(2, LoadSceneMode.Single);
        }
    }

}
