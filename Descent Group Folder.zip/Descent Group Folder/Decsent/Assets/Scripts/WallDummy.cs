﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallDummy : MonoBehaviour {

    void HitByRay()
    {
    }
    void InRange()
    {

    }
    void NotInRange()
    {

    }
}
