﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

public class XMLManager : MonoBehaviour
{//https://www.youtube.com/watch?v=6vl1IYMpwVQ
    public static XMLManager xmlman;
	// Use this for initialization
	void Awake () {
        xmlman = this;
	}

    public charsacterdatabase charerdateres;

    public void savecharacter()//saving the character
    {
        XmlSerializer seriailler = new XmlSerializer(typeof(charsacterdatabase));//this condvents unity data to xml
        FileStream stream = new FileStream(Application.dataPath+ "/Scripts/character.xml", FileMode.Create);//this creaates the file
        seriailler.Serialize(stream, charerdateres);//this wires to the database
        stream.Close();//this close's the file
    }
	public void loadcharacter()
    {// load the character
        XmlSerializer seriailler = new XmlSerializer(typeof(charsacterdatabase));// this condvents xml to unity
        FileStream stream = new FileStream(Application.dataPath + "/Scripts/character.xml", FileMode.Open);// this open the file
        charerdateres = seriailler.Deserialize(stream) as charsacterdatabase;
        stream.Close();//this close's the file
    }
}
[System.Serializable]

public class charsacterdatabase //this enaters the charasactcters
{
    public List<PlayerStats> characterentry = new List<PlayerStats>();
}






