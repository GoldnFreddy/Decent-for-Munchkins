﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class HeroButtonsScript : MonoBehaviour {
  
    public GameObject prefabManager;
    public PrefabList prefabScript;
    public int choiceCount = 1;

    //Variables for disabling buttons
    public bool b1 = false;
    public bool b2 = false;
    public bool b3 = false;
    public bool b4 = false;
    public bool b5 = false;
    public bool b6 = false;
    public bool b7 = false;
    public bool b8 = false;

    void Start()//tis insplenst the perfab list
    {
        prefabManager = GameObject.Find("PrefabMaster");
        prefabScript = prefabManager.GetComponent<PrefabList>();
    }
    public void ChooseAvric()
    {
        if (b1 == false)
        {
            b1 = true;
            //this is for choose avric 

            prefabScript.players.Add(prefabScript.Avric);
            choiceCount += 1;
            
            if (choiceCount == prefabScript.playerCount)
            {

                SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
            }
        }
    }
    public void ChooseGrisban()
    {
        if (b2 == false)
        {
            b2 = true;
            //this is for choose grisban

            prefabScript.players.Add(prefabScript.Grisban);
            choiceCount += 1;
            if (choiceCount == prefabScript.playerCount)// this load the level if all the have players select there game
            {
                SceneManager.LoadScene(2, LoadSceneMode.Single);
            }
        }
    }
    public void ChooseTomble()
    {
        if (b3 == false)
        {
            b3 = true;
            //this is for choose Tomble
            prefabScript.players.Add(prefabScript.Tomble);
            choiceCount += 1;
            if (choiceCount == prefabScript.playerCount)
            {
                SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level 
            }
        }
    }
    public void ChooseTarha()
    {
        if (b4 == false)
        {
            b4 = true;
            //this is for choose Tarha
            prefabScript.players.Add(prefabScript.Tarha);
            choiceCount += 1;
            if (choiceCount == prefabScript.playerCount)
            {
                SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
            }
        }
    }
    public void ChooseLeoric()
    {
        if (b5 == false)
        {
            b5 = true;
            //this is for choose Leoric
            prefabScript.players.Add(prefabScript.Leoric);
            choiceCount += 1;
            if (choiceCount == prefabScript.playerCount)
            {
                SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
            }
        }
    }
    public void ChooseAshrian()
    {
        if (b6 == false)
        {
            b6 = true;
            //this is for choose Ashrian
            prefabScript.players.Add(prefabScript.Ashrian);
            choiceCount += 1;
            if (choiceCount == prefabScript.playerCount)
            {
                SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
            }
        }
    }
    public void ChooseJain()
    {
        if (b7 == false)
        {
            b7 = true;
            //this is for choose Jain
            prefabScript.players.Add(prefabScript.Jain);
            choiceCount += 1;
            if (choiceCount == prefabScript.playerCount)
            {
                SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
            }
        }
    }
    public void ChooseSyndrael()
    {
        if (b8 == false)
        {
            b8 = true;
            //this is for choose Syndrael
            prefabScript.players.Add(prefabScript.Syndrael);
            choiceCount += 1;
            if (choiceCount == prefabScript.playerCount)
            {
                SceneManager.LoadScene(2, LoadSceneMode.Single);// this load the level
            }
        }
    }

}
