﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetupDestroy : MonoBehaviour {

    public GameObject setupOverlord;
    public PlayerScript setupTrigger;
    private void Start()
    {
        setupOverlord = GameObject.Find("GameManager");
        setupTrigger = setupOverlord.GetComponent<PlayerScript>();
    }
    void Update()
    {
            if(setupTrigger.newTurn == true)
            {
                Destroy(gameObject);
            }
    }
}
