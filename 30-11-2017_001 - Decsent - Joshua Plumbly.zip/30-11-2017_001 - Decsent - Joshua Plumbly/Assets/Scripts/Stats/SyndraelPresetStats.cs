﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SyndraelPresetStats : BaseCharacterClass
{
    public SyndraelPresetStats()
    {
        CharacterName = "";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Warrior;
        CharacterClass = enumCharacterClass.Error;
        Speed = 4;
        Health = 12;
        Stamina = 4;
        Defence = enumDefence.oneGrayDice;
        Might = 4;
        Knowledge = 3;
        Willpower = 2;
        Awareness = 2;
    }
}
