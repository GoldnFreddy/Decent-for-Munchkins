﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AshrianPresetStats : BaseCharacterClass
{
    public AshrianPresetStats()
    {
        CharacterName = "Ashrian";
        CharacterDescription = "";
        ArcheTypes = enumArchetypes.Healer;
        CharacterClass = enumCharacterClass.Error;
        Speed = 5;
        Health = 10;
        Stamina = 4;
        Defence = enumDefence.oneGrayDice;
        Might = 2;
        Knowledge = 2;
        Willpower = 3;
        Awareness = 4;
    }
}
