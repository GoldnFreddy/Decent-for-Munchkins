﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Raycasting : MonoBehaviour {
    //Attack script by Antoni Gudejko
    //range of attack
    [SerializeField]
    int range = 0;
    //So hit-ting it possible
    RaycastHit hit;
    //Rolling for Range
    bool rangeRoll = false;
    //Rolling for Attack
    bool attackRoll = false;
    //If attack was already done
    bool isDone = false;
    //damage of attack
    public int damage = 1;
    // Use this for initialization
    void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {
        //Calling the diceroll void
        Diceroll();
        //Highlighting enemies
        if(rangeRoll == true)
        {
            EnemyInRange();
        }
        else
        {
            EnemyNotInRange();
        }
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));
        //Debugging that tells in console if the raycasts actually hit their intended targets
        if (attackRoll == true)
        {
            if (isDone == false)
            {

                if (Input.GetKeyDown(KeyCode.W))
                {
                    if (Physics.Raycast(transform.position, fwd, out hit, range))
                    {
                        //activates void in other object with the name "hit by ray"
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;

                    }
                }
                if (Input.GetKeyDown(KeyCode.X))
                {
                    if (Physics.Raycast(transform.position, bck, out hit, range))
                    {
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;
                    }
                }
                if (Input.GetKeyDown(KeyCode.A))
                {
                    if (Physics.Raycast(transform.position, lft, out hit, range))
                    {
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;
                    }
                }
                if (Input.GetKeyDown(KeyCode.D))
                {
                    if (Physics.Raycast(transform.position, rgt, out hit, range))
                    {
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;
                    }
                }
                if (Input.GetKeyDown(KeyCode.Q))
                {
                    if (Physics.Raycast(transform.position, fwd_lft, out hit, range))
                    {
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;
                    }
                }
                if (Input.GetKeyDown(KeyCode.E))
                {
                    if (Physics.Raycast(transform.position, fwd_rgt, out hit, range))
                    {
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;
                    }
                }
                if (Input.GetKeyDown(KeyCode.Z))
                {
                    if (Physics.Raycast(transform.position, bck_lft, out hit, range))
                    {
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;
                    }
                }
                if (Input.GetKeyDown(KeyCode.C))
                {
                    if (Physics.Raycast(transform.position, bck_rgt, out hit, range))
                    {
                        hit.transform.SendMessage("HitByRay");
                        isDone = true;
                        range = 0;
                    }
                }
            }
        }
        
    }
    void Diceroll()
    {
        //rolling dice to get results
        if (rangeRoll == false)
        {
            if (Input.GetKeyDown(KeyCode.S))
            {
                range = Random.Range(0, 10);
                rangeRoll = true;
                Debug.Log("You rolled " + range + " for range.");
            }
        }
        else
        {
            if (attackRoll == false)
            {
                if (Input.GetKeyDown(KeyCode.S))
                {
                    damage = Random.Range(1, 6);
                    attackRoll = true;
                    isDone = false;
                    Debug.Log("You rolled " + damage + " for attack.");
                }
            }
            else
            {
                if (Input.GetKeyDown(KeyCode.S))
                {
                    attackRoll = false;
                    rangeRoll = false;
                    range = 0;
                    damage = 0;
                    Debug.Log("You ended your turn");
                }
            }

        }
        
    }
    void EnemyInRange()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));

        if (Physics.Raycast(transform.position, fwd, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, lft, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, rgt, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, fwd_lft, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, fwd_rgt, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck_lft, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
        if (Physics.Raycast(transform.position, bck_rgt, out hit, range))
        {
            hit.transform.SendMessage("InRange");
        }
    }
    void EnemyNotInRange()
    {
        //Vectors checking for enemies in all possible directions
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Vector3 bck = transform.TransformDirection(Vector3.back);
        Vector3 lft = transform.TransformDirection(Vector3.left);
        Vector3 rgt = transform.TransformDirection(Vector3.right);
        Vector3 fwd_lft = transform.TransformDirection(new Vector3(-1, 0, 1));
        Vector3 fwd_rgt = transform.TransformDirection(new Vector3(1, 0, 1));
        Vector3 bck_lft = transform.TransformDirection(new Vector3(-1, 0, -1));
        Vector3 bck_rgt = transform.TransformDirection(new Vector3(1, 0, -1));

        if (Physics.Raycast(transform.position, fwd, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, fwd_lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, fwd_rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck_lft, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
        if (Physics.Raycast(transform.position, bck_rgt, out hit, 10))
        {
            hit.transform.SendMessage("NotInRange");
        }
    }
}
