﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridHighlight : MonoBehaviour {

    public static GridHighlight Instance { set; get; }

    public GameObject movementHighlightPrefab;
    private List<GameObject> movementHighlightsList;

    public GameObject attackHighlightPrefab;
    private List<GameObject> attackHighlightsList;

    private void Start()
    {
        Instance = this;
        movementHighlightsList = new List<GameObject>();
        attackHighlightsList = new List<GameObject>();


    }

#region Movement region
    private GameObject GetMovementHighlightObject()
    {
        GameObject go = movementHighlightsList.Find(g => !g.activeSelf);

        if (go == null)
        {
            go = Instantiate(movementHighlightPrefab);
            movementHighlightsList.Add(go);
        }

        return go;
    }

    public void HighightAllowedMoves(bool[,] moves)
    {
        for(int i = 0; i < 13; i++)
        {
            for (int j = 0; j < 13; j++)
            {
                if (moves [i,j])
                {
                    GameObject go = GetMovementHighlightObject();
                    go.SetActive(true);
                    go.transform.position = new Vector3(i+0.5f, 0, j+0.5f);
                }
            }
        }
    }

    public void HideMovementHighlights()
    {
        foreach (GameObject go in movementHighlightsList)
            go.SetActive(false);
    }

    #endregion
    private GameObject GetAttackHighlightObject()
    {
        GameObject go = attackHighlightsList.Find(g => !g.activeSelf);

        if (go == null)
        {
            go = Instantiate(attackHighlightPrefab);
            attackHighlightsList.Add(go);
        }

        return go;
    }

    public void HighightAllowedTargets(bool[,] targets)
    {
        for (int i = 0; i < 13; i++)
        {
            for (int j = 0; j < 13; j++)
            {
                if (targets[i, j])
                {
                    GameObject go = GetAttackHighlightObject();
                    go.SetActive(true);
                    go.transform.position = new Vector3(i + 0.5f, 0, j + 0.5f);
                }
            }
        }
    }

    public void HideAttackHighlights()
    {
        foreach (GameObject go in attackHighlightsList)
            go.SetActive(false);
    }
    #region Attack region




    #endregion
}