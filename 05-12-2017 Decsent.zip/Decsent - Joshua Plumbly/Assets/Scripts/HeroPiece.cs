﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BaseCharacterClass))]

public class HeroPiece : Piece {

    [SerializeField] private BaseCharacterClass CharacterClass;
    [SerializeField] private AttackSystem attackSystem;

    public void GetClasses()
    {
        CharacterClass = this.GetComponent<BaseCharacterClass>();
        attackSystem = this.GetComponent<AttackSystem>();
        NullCheckComponents();
    }

    /// This funcion checks that components have been recived from the 'GetComponent'.
    /// If any of the components have come througe this funcion with idety any null refrances and display any errors in the debug menu.
    public void NullCheckComponents()
    {
        if (CharacterClass == null)
        {
            Debug.LogError(this.name + " can not find a suitable HeroStats class.");
        }
    }

#region Scan board for possible moves
    /// <summary>
    /// This funcion scans each tile to find evary possible move a piece can make.
    /// </summary>
    /// <returns></returns>
    public override bool[,] PossibleMove()
    {
        GetClasses();

        bool[,] r = new bool[13, 13];

        Piece p;
        int i;

        ///RIGHT
        i = CurrentX;
        while (true)
        {
            i++;
            if (i >= 13 || i > CurrentX + CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[i, CurrentY];
            if (p == null)
                r[i, CurrentY] = true;
            else
                break;
        }

        ///LEFT
        i = CurrentX;
        while (true)
        {
            i--;
            if (i < 0 || i < CurrentX - CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[i, CurrentY];
            if (p == null)
                r[i, CurrentY] = true;
            else
                break;
        }

        ///UP
        i = CurrentY;
        while (true)
        {
            i++;
            if (i >= 13 || i > CurrentY + CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[CurrentX, i];
            if (p == null|| i > CurrentX + CharacterClass.Speed)
                r[CurrentX, i] = true;
            else
                break;
        }

        ///DWON
        i = CurrentY;
        while (true)
        {
            i--;
            if (i < 0 || i < CurrentY - CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[CurrentX, i];
            if (p == null)
                r[CurrentX, i] = true;
            else
                break;
        }

        //r[10, 10] = true;
        return r;
    }
#endregion

#region Scan board for possible targets
    /// <summary>
    /// Get possible targets.
    /// </summary>
    /// <returns></returns>
    public override bool[,] PossibleTargets()
    {
        //GetClasses();

        bool[,] r = new bool[13, 13];

        Piece p;
        int i;

        ///RIGHT
        i = CurrentX;
        while (true)
        {
            i++;
            Debug.Log(i);
            if (i >= 13 || i > CurrentX + CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[i, CurrentY];
            if (p != null)
                r[i, CurrentY] = true;
        }

        ///LEFT
        i = CurrentX-1;
        while (true)
        {
            i--;
            if (i < 0 || i < CurrentX - CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[i, CurrentY];
            if (p != null)
                r[i, CurrentY] = true;
        }

        ///UP
        i = CurrentY+1;
        while (true)
        {
            i++;
            if (i != 13 || i > CurrentY + CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[CurrentX, i];
            if (p == null || i > CurrentX + CharacterClass.Speed)
                r[CurrentX, i] = true;
        }

        ///DWON
        i = CurrentY-1;
        while (true)
        {
            i--;
            if (i <= 0 || i < CurrentY - CharacterClass.Speed)
                break;

            p = GridManager.Instance.Pieces[CurrentX, i];
            if (p != null)
                r[CurrentX, i] = true;
        }

        //r[9, 9] = true;
        return r;
    }
    #endregion
}
