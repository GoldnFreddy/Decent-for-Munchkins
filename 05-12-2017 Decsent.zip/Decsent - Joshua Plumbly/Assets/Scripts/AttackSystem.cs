﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BaseCharacterClass))]

public class AttackSystem : Piece
{
    #region Varibles
    [SerializeField] public static AttackSystem Instance { set; get; }
    [SerializeField] private BaseCharacterClass CharacterClass;
    [SerializeField] private int rangeRolled;
    [SerializeField] private bool rangeSuccess;
    [SerializeField] private int attackRolled;
    [SerializeField] private int defenceRolled;
    [SerializeField] private int endDamage;
    [SerializeField] private enum NextDiceRollEnum
    {
        range,
        attack,
        defence
    }
    [SerializeField] private NextDiceRollEnum nextDiceRoll;
    #endregion

    public void GetClasses()
    {
        Debug.Log("AttackSystem is here.");
        CharacterClass = this.GetComponent<BaseCharacterClass>();
        NullCheckComponents();
    }

    /// This funcion checks that components have been recived from the 'GetComponent'.
    /// If any of the components have come througe this funcion with idety any null refrances and display any errors in the debug menu.
    public void NullCheckComponents()
    {
        if (CharacterClass == null)
        {
            Debug.LogError(this.name + " can not find a suitable HeroStats class.");
        }
    }

    public void Attack(HealthManager _targetsHealthManager)
    {
        if (nextDiceRoll == NextDiceRollEnum.range)
        {
            RangeDiceRoll();
            nextDiceRoll = NextDiceRollEnum.attack;
            Debug.Log("You rolled " + rangeRolled + " for range.");
        }
        else if (nextDiceRoll == NextDiceRollEnum.attack)
        {
            AttackDiceRoll();
            nextDiceRoll = NextDiceRollEnum.defence;
            Debug.Log("You rolled " + attackRolled + " for damage.");
        }
        else if (nextDiceRoll == NextDiceRollEnum.defence)
        {
            DefenceDiceRoll();
            nextDiceRoll = NextDiceRollEnum.range;

            endDamage = attackRolled - defenceRolled;

            if (endDamage < 0)
                endDamage = 0;

            _targetsHealthManager.TakeDamage(endDamage);
        }
    }

    void RangeDiceRoll()
    {
        int i = Random.Range(0, 6);
        switch (i)
        {
            case 0:
                attackRolled = 0;
                break;
            case 1:
                attackRolled = 2;
                break;
            case 2:
                attackRolled = 3;
                break;
            case 3:
                attackRolled = 4;
                break;
            case 4:
                attackRolled = 5;
                break;
            case 5:
                attackRolled = 6;
                break;
        }
    }

    void AttackDiceRoll()
    {
        int i = Random.Range(0, 6);
        switch(i)
        {
            case 0:
                attackRolled = 0;
                break;
            case 1:
                attackRolled = 2;
                break;
            case 2:
                attackRolled = 2;
                break;
            case 3:
                attackRolled = 2;
                break;
            case 4:
                attackRolled = 1;
                break;
            case 5:
                attackRolled = 1;
                break;
        }
    }

    void DefenceDiceRoll()
    {
        int i = Random.Range(0, 6);
        switch (i)
        {
            case 0:
                defenceRolled = 0;
                break;
            case 1:
                defenceRolled = 1;
                break;
            case 2:
                defenceRolled = 1;
                break;
            case 3:
                defenceRolled = 1;
                break;
            case 4:
                defenceRolled = 2;
                break;
            case 5:
                defenceRolled = 3;
                break;
        }
    }
}